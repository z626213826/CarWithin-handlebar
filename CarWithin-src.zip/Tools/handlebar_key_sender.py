#!/usr/bin/env python3
"""车把按键调试/桥接工具：把按键名发到 CarWithin 的 UDP 5014。

用法：
  python handlebar_key_sender.py 192.168.1.5            # 交互：输入 up / down / ok ...，回车发送
  python handlebar_key_sender.py 192.168.1.5 5014 up     # 单发一次
  python handlebar_key_sender.py 192.168.1.5 --keys up,up,ok   # 连发多个

iPhone 上需先启动 CarWithin 的九号 5/7/4.3 寸模式；日志出现
「车把按键通道已监听 UDP 5014」即表示可接收。
"""
import argparse
import socket
import sys
import time

KEYS = ["up", "down", "ok", "back", "mode", "horn",
        "leftTurn", "rightTurn", "highBeam", "plus", "minus", "home", "hook"]


def send(host: str, port: int, key: str, as_json: bool) -> None:
    payload = '{"key":"%s"}' % key if as_json else key
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.sendto(payload.encode("utf-8"), (host, port))
    finally:
        sock.close()
    print("sent -> %s:%d  %s" % (host, port, payload))


def main() -> int:
    parser = argparse.ArgumentParser(description="向 CarWithin 发送车把按键")
    parser.add_argument("host", help="运行 CarWithin 的 iPhone 局域网 IP")
    parser.add_argument("key", nargs="?", help="按键名；省略则进入交互模式")
    parser.add_argument("--port", type=int, default=5014)
    parser.add_argument("--keys", help="逗号分隔的按键序列，例如 up,up,ok")
    parser.add_argument("--json", action="store_true", help="发送 JSON 报文而不是纯文本")
    parser.add_argument("--interval", type=float, default=0.4, help="连发间隔秒数")
    args = parser.parse_args()

    if args.keys:
        for key in [item.strip() for item in args.keys.split(",") if item.strip()]:
            send(args.host, args.port, key, args.json)
            time.sleep(args.interval)
        return 0

    if args.key:
        send(args.host, args.port, args.key, args.json)
        return 0

    print("交互模式：输入按键名后回车发送，空行退出。可用：%s" % ", ".join(KEYS))
    for line in sys.stdin:
        key = line.strip()
        if not key:
            break
        send(args.host, args.port, key, args.json)
    return 0


if __name__ == "__main__":
    sys.exit(main())
