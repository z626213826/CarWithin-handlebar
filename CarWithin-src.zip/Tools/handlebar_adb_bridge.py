#!/usr/bin/env python3
"""经 adb 把九号仪表（Android）的车把按键转发到 CarWithin。

前提：仪表已开启 USB/无线调试，本机 `adb devices` 能看到它。

用法：
  python handlebar_adb_bridge.py 192.168.1.5 --device <序列号>
  python handlebar_adb_bridge.py 192.168.1.5 --device <序列号> --dump

--dump 只打印抓到的 keycode，不发送，用于第一次确认车把按键对应哪个 keycode。
把打印出的 keycode 加进 KEYMAP，即可让对应车把键触发 CarPlay 动作。
"""
import argparse
import re
import socket
import subprocess
import sys

# Android keycode -> CarWithin 按键名。第一次请用 --dump 实车按键确认后补全。
KEYMAP = {
    19: "up",        # KEYCODE_DPAD_UP
    20: "down",      # KEYCODE_DPAD_DOWN
    21: "ok",        # 部分仪表用 DPAD_LEFT 作为确认
    22: "back",
    23: "ok",        # KEYCODE_DPAD_CENTER
    4: "back",       # KEYCODE_BACK
    24: "plus",      # KEYCODE_VOLUME_UP
    25: "minus",     # KEYCODE_VOLUME_DOWN
    87: "rightTurn", # KEYCODE_MEDIA_NEXT
    88: "leftTurn",  # KEYCODE_MEDIA_PREVIOUS
    85: "mode",      # KEYCODE_MEDIA_PLAY_PAUSE
    84: "horn",      # KEYCODE_SEARCH（不少车机把自定义键映射到这里）
    231: "home",     # KEYCODE_HOME
    5: "hook",       # KEYCODE_CALL
}

# getevent -lt 的一行： [   12345.678] /dev/input/event2: EV_KEY       KEY_VOLUMEUP     DOWN
EVENT = re.compile(r"/dev/input/event\d+:\s+EV_KEY\s+(\w+)\s+(DOWN|UP)")
NAME_TO_CODE = {}


def load_keymap(device: str) -> None:
    """用 getevent -S 的名称表补充自定义键，失败则沿用内置表。"""
    try:
        out = subprocess.run(["adb", "-s", device, "shell", "getevent", "-S"],
                             capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return
    for line in out.splitlines():
        match = re.search(r"(\w+)\s+([0-9a-fA-F]{8})", line)
        if match:
            NAME_TO_CODE[match.group(1)] = int(match.group(2), 16)


def main() -> int:
    parser = argparse.ArgumentParser(description="adb 车把按键桥")
    parser.add_argument("host", help="运行 CarWithin 的 iPhone 局域网 IP")
    parser.add_argument("--device", help="adb 设备序列号；只有一台时可省略")
    parser.add_argument("--port", type=int, default=5014)
    parser.add_argument("--dump", action="store_true", help="只打印 keycode，不发送")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    command = ["adb"] + (["-s", args.device] if args.device else []) + ["shell", "getevent", "-lt"]
    print(" ".join(command))
    if args.device:
        load_keymap(args.device)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True, bufsize=1)
    try:
        for line in process.stdout:
            match = EVENT.search(line)
            if not match:
                continue
            name, action = match.group(1), match.group(2)
            if action != "DOWN":
                continue
            code = NAME_TO_CODE.get(name)
            key = KEYMAP.get(code) if code is not None else None
            print("event: %s code=%s -> %s" % (name, code, key or "未映射"))
            if args.dump or key is None:
                continue
            payload = '{"key":"%s"}' % key if args.json else key
            sock.sendto(payload.encode("utf-8"), (args.host, args.port))
    except KeyboardInterrupt:
        pass
    finally:
        process.terminate()
        sock.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
