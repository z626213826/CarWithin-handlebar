import UIKit
import CoreGraphics

/// Owns ANT telemetry and settings independently of CarPlay connection configuration.
/// CoreBluetooth callbacks and all UI work stay on the main queue.
final class ANTBMSController: NSObject {
    var onImage: ((CGImage?, ANTBMSCardConfiguration) -> Void)?
    var onLog: ((String) -> Void)?
    var aspectRatio: CGFloat = 848 / 480 { didSet { if aspectRatio != oldValue { refreshBMS() } } }
    private weak var rootPage: SettingsPageController?
    private var lastSelectedID: UUID?
    private let bmsClient = ANTBMSClient(family: .ant)
    private let jbdClient = ANTBMSClient(family: .jbd)
    private let luxingClient = ANTBMSClient(family: .luxing)
    private let jkClient = ANTBMSClient(family: .jikong)
    private let bmsOverlay = BMSOverlayPresenter()
    private let bmsEnabledSwitch = UISwitch()
    private let jbdEnabledSwitch = UISwitch()
    private let luxingEnabledSwitch = UISwitch()
    private let jkEnabledSwitch = UISwitch()
    private let bmsPosition = ChoiceMenu(items: ANTBMSCardConfiguration.Position.allCases.map(\.title))
    private let bmsCardSize = ChoiceMenu(items: ANTBMSCardConfiguration.Size.allCases.map(\.title))
    private let bmsCardBackground = ChoiceMenu(items: ANTBMSCardConfiguration.Background.allCases.map(\.title))
    private var bmsCardConfiguration = ANTBMSCardConfiguration()
    private var bmsFieldSwitches: [ANTBMSCardConfiguration.Field: UISwitch] = [:]
    private let bmsCardPreview = BMSCardPreviewView()
    private let bmsCardPreviewStatus = StatusLabel()
    private let bmsStatus = StatusLabel()
    private let jbdStatus = StatusLabel()
    private let luxingStatus = StatusLabel()
    private let jkStatus = StatusLabel()
    private let bmsDetails = StatusLabel()
    private let bmsLiveSummary = BMSLiveSummaryView()
    private var bmsDeviceList: [UUID] = []

    /// 三族共用一套卡片与投屏层，读数取第一个"已开启且有新鲜数据"的板。
    private var allClients: [(family: BMSFamily, client: ANTBMSClient, toggle: UISwitch)] {
        [(family: .ant, client: bmsClient, toggle: bmsEnabledSwitch),
         (family: .jbd, client: jbdClient, toggle: jbdEnabledSwitch),
         (family: .luxing, client: luxingClient, toggle: luxingEnabledSwitch),
         (family: .jikong, client: jkClient, toggle: jkEnabledSwitch)]
    }
    private var anyEnabled: Bool { allClients.contains { $0.toggle.isOn } }
    private var activeClient: ANTBMSClient? {
        let enabled = allClients.filter { $0.toggle.isOn }.map { $0.client }
        if let fresh = enabled.first(where: { $0.freshReading != nil }) { return fresh }
        return enabled.first
    }
    private var activeReading: ANTBMSReading? { activeClient?.freshReading }
    private var activeStatus: String {
        guard anyEnabled else { return "BMS 显示已关闭" }
        return activeClient?.status ?? "未选择 BMS"
    }

    override init() {
        super.init()
        configureBMS()
    }

    func attach(to surface: UIView) {
        bmsOverlay.attach(to: surface)
        refreshBMS()
    }

    private func page(_ title: String, _ build: @escaping () -> [SettingsSection]) -> SettingsPageController {
        SettingsPageController(title: title, build: build)
    }
    private func reloadVisibleSettings() {
        (rootPage?.navigationController?.topViewController as? SettingsPageController)?.reload()
    }
    private func alert(_ title: String, _ message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        let presenter: UIViewController? = rootPage?.navigationController ?? rootPage
        presenter?.present(alert, animated: true)
    }

    private func configureBMS() {
        for entry in allClients {
            entry.toggle.isOn = UserDefaults.standard.bool(forKey: "\(entry.family.rawValue)BMSEnabled")
            entry.toggle.addTarget(self, action: #selector(bmsSettingsChanged), for: .valueChanged)
        }
        bmsPosition.addTarget(self, action: #selector(bmsCardAppearanceChanged), for: .valueChanged)
        bmsCardBackground.addTarget(self, action: #selector(bmsCardAppearanceChanged), for: .valueChanged)
        bmsCardConfiguration = ANTBMSCardConfiguration(
            savedFields: UserDefaults.standard.stringArray(forKey: "antBMSCardFields"),
            sizeRawValue: UserDefaults.standard.object(forKey: "antBMSCardSize") as? Int,
            positionRawValue: UserDefaults.standard.object(forKey: "antBMSPosition") as? Int,
            backgroundRawValue: UserDefaults.standard.object(forKey: "antBMSCardBackground") as? Int)
        bmsCardSize.selectedSegmentIndex = bmsCardConfiguration.size.rawValue
        bmsPosition.selectedSegmentIndex = bmsCardConfiguration.position.rawValue
        bmsCardBackground.selectedSegmentIndex = bmsCardConfiguration.background.rawValue
        bmsCardSize.addTarget(self, action: #selector(bmsCardSizeChanged), for: .valueChanged)
        for field in ANTBMSCardConfiguration.Field.allCases {
            let control = UISwitch()
            control.isOn = bmsCardConfiguration.fields.contains(field)
            control.addAction(UIAction { [weak self, weak control] _ in
                guard let self, let control else { return }
                guard self.bmsCardConfiguration.set(field, visible: control.isOn) else {
                    control.setOn(true, animated: true)
                    self.alert("至少显示一项", "如需隐藏整张卡片，请关闭「读取并显示 BMS」。")
                    return
                }
                self.saveBMSCardConfiguration()
            }, for: .valueChanged)
            bmsFieldSwitches[field] = control
        }
        bmsDetails.numberOfLines = 0
        bmsDetails.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
        bmsOverlay.onImage = { [weak self] image, configuration in
            self?.onImage?(image, configuration)
        }
        for entry in allClients {
            entry.client.onLog = { [weak self] message in self?.onLog?(message) }
            entry.client.onChange = { [weak self] in self?.refreshBMS() }
            if entry.toggle.isOn { entry.client.start() }
        }
        refreshBMS()
    }

    @objc private func bmsSettingsChanged() {
        for entry in allClients {
            UserDefaults.standard.set(entry.toggle.isOn, forKey: "\(entry.family.rawValue)BMSEnabled")
            if entry.toggle.isOn { entry.client.start() } else { entry.client.stop() }
        }
        refreshBMS()
        reloadVisibleSettings()
    }

    @objc private func bmsCardSizeChanged() {
        bmsCardConfiguration.size = ANTBMSCardConfiguration.Size(rawValue: bmsCardSize.selectedSegmentIndex) ?? .medium
        saveBMSCardConfiguration()
    }

    @objc private func bmsCardAppearanceChanged() {
        bmsCardConfiguration.position = ANTBMSCardConfiguration.Position(rawValue: bmsPosition.selectedSegmentIndex) ?? .topRight
        bmsCardConfiguration.background = ANTBMSCardConfiguration.Background(rawValue: bmsCardBackground.selectedSegmentIndex) ?? .standard
        saveBMSCardConfiguration()
    }

    private func saveBMSCardConfiguration() {
        UserDefaults.standard.set(bmsCardConfiguration.fields.map(\.rawValue), forKey: "antBMSCardFields")
        UserDefaults.standard.set(bmsCardConfiguration.size.rawValue, forKey: "antBMSCardSize")
        UserDefaults.standard.set(bmsCardConfiguration.position.rawValue, forKey: "antBMSPosition")
        UserDefaults.standard.set(bmsCardConfiguration.background.rawValue, forKey: "antBMSCardBackground")
        refreshBMS()
        reloadVisibleSettings()
    }

    private func applyBMSCardPreset(_ fields: [ANTBMSCardConfiguration.Field]) {
        bmsCardConfiguration = ANTBMSCardConfiguration(savedFields: fields.map(\.rawValue),
            sizeRawValue: bmsCardConfiguration.size.rawValue,
            positionRawValue: bmsCardConfiguration.position.rawValue,
            backgroundRawValue: bmsCardConfiguration.background.rawValue)
        for (field, control) in bmsFieldSwitches { control.isOn = bmsCardConfiguration.fields.contains(field) }
        saveBMSCardConfiguration()
    }

    private func refreshBMS() {
        let reading = activeReading
        bmsStatus.text = bmsEnabledSwitch.isOn ? bmsClient.status : "BMS 显示已关闭"
        jbdStatus.text = jbdEnabledSwitch.isOn ? jbdClient.status : "BMS 显示已关闭"
        luxingStatus.text = luxingEnabledSwitch.isOn ? luxingClient.status : "BMS 显示已关闭"
        jkStatus.text = jkEnabledSwitch.isOn ? jkClient.status : "BMS 显示已关闭"
        bmsLiveSummary.update(reading)
        if let reading {
            let temperature = reading.maximumTemperature.map { String(format: "%.0f°C", $0) } ?? "--"
            let mos = reading.mosTemperature.map { String(format: "%.0f°C", $0) } ?? "--"
            let delta = reading.cellDelta.map { String(format: "%.0f mV", $0 * 1000) } ?? "--"
            let states = [0: "无状态", 1: "静止", 2: "充电", 3: "待机", 4: "放电", 5: "异常"]
            bmsDetails.text = String(format: "电量 %d%% · %.2f V · %+.1f A · %d W\n剩余 %.2f / %.2f Ah\n最高温度 %@ · MOS %@\n%d 串 · 单体压差 %@\n状态：%@\n保护位：0x%llX · 告警位：0x%llX",
                reading.stateOfCharge, reading.voltage, reading.current, reading.power,
                reading.remainingAh, reading.capacityAh, temperature, mos, reading.cells.count, delta,
                states[reading.stateCode] ?? "未知", reading.protectionBits, reading.alarmBits)
        } else {
            bmsDetails.text = "电量 -- · 电压 -- · 电流 -- · 功率 --\n等待校验有效的 BMS 实时数据。"
        }
        bmsOverlay.update(enabled: anyEnabled, reading: reading, status: activeStatus,
                          configuration: bmsCardConfiguration)
        bmsCardPreview.update(reading: reading, configuration: bmsCardConfiguration,
                             aspectRatio: aspectRatio)
        bmsCardPreviewStatus.text = reading == nil ? "示例数据 · 当前没有实时读数"
            : "实时数据 · 当前连接 \(activeClient?.familyTitle ?? "BMS")"
        let ids = activeClient?.devices.map(\.id) ?? []
        if ids != bmsDeviceList || activeClient?.selectedID != lastSelectedID {
            lastSelectedID = activeClient?.selectedID
            bmsDeviceList = ids
            reloadVisibleSettings()
        }
    }
    func settingsPage() -> SettingsPageController {
        let root = page("电池与 BMS") { [unowned self] in
            [SettingsSection("蚂蚁 ANT BMS", [
                .control("读取并显示 BMS", self.bmsEnabledSwitch),
                .note(self.bmsStatus),
                .page("连接设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue), detail: { [unowned self] in
                    self.bmsClient.selectedName
                }) { [unowned self] in self.bmsDevicesPage(.ant) }
            ]),
            SettingsSection("嘉佰达 JBD BMS", [
                .control("读取并显示 BMS", self.jbdEnabledSwitch),
                .note(self.jbdStatus),
                .page("连接设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue), detail: { [unowned self] in
                    self.jbdClient.selectedName
                }) { [unowned self] in self.bmsDevicesPage(.jbd) }
            ]),
            SettingsSection("陆行电量计 EM2APP", footer: "嘉佰达/极空板 + 陆行计量模块的车型选这一项：它用 Modbus 读寄存器，不是嘉佰达原始协议。", [
                .control("读取并显示 BMS", self.luxingEnabledSwitch),
                .note(self.luxingStatus),
                .page("连接设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue), detail: { [unowned self] in
                    self.luxingClient.selectedName
                }) { [unowned self] in self.bmsDevicesPage(.luxing) }
            ]),
            SettingsSection("极空 JK BMS", [
                .control("读取并显示 BMS", self.jkEnabledSwitch),
                .note(self.jkStatus),
                .page("连接设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue), detail: { [unowned self] in
                    self.jkClient.selectedName
                }) { [unowned self] in self.bmsDevicesPage(.jikong) }
            ]),
            SettingsSection("实时电池", footer: "只显示最近 5 秒内的有效数据，断开后自动清空旧值。三家保护板共用同一张投屏卡片，同时开启时优先显示有新鲜数据的那一家。", [.view(self.bmsLiveSummary)]),
            SettingsSection("卡片与详情", [
                .page("卡片显示", icon: ("rectangle.topthird.inset.filled", .systemBlue), detail: { [unowned self] in
                    "\(self.bmsCardConfiguration.fields.count) 项 · \(self.bmsCardConfiguration.size.title)号"
                }) { [unowned self] in self.bmsCardPage() },
                .page("电池详情", icon: ("list.bullet.rectangle", .systemGray)) { [unowned self] in
                    self.page("电池详情") { [unowned self] in
                        [SettingsSection("实时参数", footer: "电流符号按各家原始定义换算，正为充电、负为放电。容量、温度、串数和状态由保护板上报。", [.note(self.bmsDetails)])]
                    }
                }
            ])]
        }
        rootPage = root
        return root
    }

    private func bmsDevicesPage(_ family: BMSFamily) -> SettingsPageController {
        let client: ANTBMSClient
        let toggle: UISwitch
        let status: StatusLabel
        switch family {
        case .ant: client = bmsClient; toggle = bmsEnabledSwitch; status = bmsStatus
        case .jbd: client = jbdClient; toggle = jbdEnabledSwitch; status = jbdStatus
        case .luxing: client = luxingClient; toggle = luxingEnabledSwitch; status = luxingStatus
        case .jikong: client = jkClient; toggle = jkEnabledSwitch; status = jkStatus
        }
        return page("\(family.title) 连接") { [unowned self] in
            var sections = [SettingsSection("当前设备", [
                .info("已记住的设备", client.selectedName),
                .note(status)
            ])]
            guard toggle.isOn else {
                sections.append(SettingsSection(footer: "开启读取后搜索并选择自己的 \(family.short) 保护板。", [
                    .action("开启读取并查找设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue)) {
                        toggle.setOn(true, animated: false)
                        self.bmsSettingsChanged()
                    }
                ]))
                return sections
            }
            sections.append(SettingsSection(footer: "选定后会记住并自动重连。连接不上时，先断开手机上的厂商 App。", [
                .action("扫描附近 BMS", icon: ("antenna.radiowaves.left.and.right", .systemBlue)) { client.scan() },
                .action("忘记当前 BMS", destructive: true) {
                    client.forget()
                    self.reloadVisibleSettings()
                }
            ]))
            let devices = client.devices.map { device in
                var row = SettingsRow.action(device.name, detail: { "\(device.rssi) dBm" }) { client.select(device.id) }
                row.checked = { client.selectedID == device.id }
                return row
            }
            sections.append(SettingsSection("附近设备", footer: "只读 \(family.channelHint) 通道；扫描到同名设备不代表协议兼容，收到校验有效的实时帧才会显示数据。",
                devices.isEmpty ? [.info("暂无设备", "点击上方扫描")] : devices))
            return sections
        }
    }

    private func bmsCardPage() -> SettingsPageController {
        bmsCardPreview.update(reading: activeReading, configuration: bmsCardConfiguration,
                             aspectRatio: aspectRatio)
        return page("BMS 卡片显示") { [unowned self] in
            var sections = [SettingsSection("布局", footer: "修改后立即同步到手机和九号五寸、七寸投屏，并自动保存。卡片最多两行；减少显示项可留出更多地图空间。", [
                .control("字号", self.bmsCardSize),
                .control("显示位置", self.bmsPosition),
                .control("背景", self.bmsCardBackground),
                .page("字段顺序", icon: ("arrow.up.arrow.down", .systemBlue)) { [unowned self] in
                    BMSCardOrderViewController(fields: self.bmsCardConfiguration.fields) { [weak self] field, destination in
                        guard let self else { return }
                        self.bmsCardConfiguration.move(field, to: destination)
                        self.saveBMSCardConfiguration()
                    }
                }
            ])]
            sections.append(SettingsSection("布局预览", footer: "背景为布局示意，比例随所选仪表变化。没有实时读数时使用示例数据，示例不会进入实时读数或投屏画面。", [
                .note(self.bmsCardPreviewStatus), .view(self.bmsCardPreview)
            ]))
            sections.append(SettingsSection("快捷布局", [
                .action("精简：电量、总压、压差", icon: ("minus.circle", .systemBlue)) { [unowned self] in
                    self.applyBMSCardPreset(ANTBMSCardConfiguration.compactFields)
                },
                .action("常用：显示全部六项", icon: ("square.grid.2x2", .systemBlue)) { [unowned self] in
                    self.applyBMSCardPreset(ANTBMSCardConfiguration.Field.allCases)
                }
            ]))
            let fields = ANTBMSCardConfiguration.Field.allCases.compactMap { field -> SettingsRow? in
                guard let control = self.bmsFieldSwitches[field] else { return nil }
                return .control(field.title, control)
            }
            sections.append(SettingsSection("显示内容", footer: "至少保留一项。单体压差以 mV 显示；未知读数显示 --，BMS 告警会保留提示。", fields))
            return sections
        }
    }


}
