import CoreBluetooth
import Foundation
import UIKit

/// 支持的第三方保护板族。三族共用一套只读 BLE 连接器，仅通道 UUID、解析器和查询帧不同。
enum BMSFamily: String, CaseIterable {
    case ant
    case jbd
    case luxing
    case jikong

    var title: String {
        switch self {
        case .ant: return "蚂蚁 ANT BMS"
        case .jbd: return "嘉佰达 JBD BMS"
        case .luxing: return "陆行电量计 EM2APP"
        case .jikong: return "极空 JK BMS"
        }
    }

    var short: String {
        switch self {
        case .ant: return "ANT"
        case .jbd: return "JBD"
        case .luxing: return "陆行"
        case .jikong: return "JK"
        }
    }

    /// 主服务 + 兼容服务：嘉佰达多数是 FF00，串口模块版在 FFE0 下。
    var serviceUUIDs: [CBUUID] {
        switch self {
        case .ant, .luxing, .jikong: return [CBUUID(string: "FFE0")]
        case .jbd: return [CBUUID(string: "FF00"), CBUUID(string: "FFE0")]
        }
    }

    var writeUUID: CBUUID {
        switch self {
        case .ant, .jikong: return CBUUID(string: "FFE1")
        case .jbd: return CBUUID(string: "FF02")
        case .luxing: return CBUUID(string: "FFE2")
        }
    }

    var notifyUUID: CBUUID {
        switch self {
        case .ant, .luxing, .jikong: return CBUUID(string: "FFE1")
        case .jbd: return CBUUID(string: "FF01")
        }
    }

    var namePrefixes: [String] {
        switch self {
        case .ant: return ["ANT", "AN"]
        case .jbd: return ["JBD", "JB", "SP04", "SP0"]
        case .luxing: return ["EM2", "EM", "LX"]
        case .jikong: return ["JK", "JKB"]
        }
    }

    var channelHint: String {
        switch self {
        case .ant: return "FFE0 / FFE1"
        case .jbd: return "FF00 / FF01·FF02"
        case .luxing: return "FFE0 / FFE1·FFE2"
        case .jikong: return "FFE0 / FFE1"
        }
    }
}

/// 解析器多态：三族各有自己的帧格式，对外只暴露"下一帧该发什么"和"喂入收到的字节"。
final class BMSDecoder {
    private let family: BMSFamily
    private var ant = ANTBMSProtocol()
    private var jbd = JBDBMSProtocol()
    private var luxing = LuXingMeterProtocol()
    private var jikong = JKBMSProtocol()

    init(family: BMSFamily) { self.family = family }

    func append(_ data: Data) -> ANTBMSReading? {
        switch family {
        case .ant: return ant.append(data).last
        case .jbd: return jbd.append(data).last
        case .luxing: return luxing.append(data).last
        case .jikong: return jikong.append(data).last
        }
    }

    func nextQuery() -> Data {
        switch family {
        case .ant: return ANTBMSProtocol.realtimeRequest
        case .jbd: return jbd.nextQuery()
        case .luxing: return luxing.nextQueries().first ?? Data()
        case .jikong: return jikong.nextQuery()
        }
    }

    /// 陆行一个节拍要连发多条 Modbus 读，其余族只有一条。
    func nextQueries() -> [Data] {
        switch family {
        case .luxing: return luxing.nextQueries()
        default: return [nextQuery()]
        }
    }

    func reset() {
        ant = ANTBMSProtocol(); jbd = JBDBMSProtocol()
        luxing = LuXingMeterProtocol(); jikong = JKBMSProtocol()
    }
}

/// 只读第三方 BMS 遥测，全部在主队列。设备由用户显式选择并按 CoreBluetooth UUID 记住。
final class ANTBMSClient: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    struct Device {
        let id: UUID
        let name: String
        let rssi: Int
    }

    private let family: BMSFamily
    private let defaults: UserDefaults
    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var discovered: [UUID: CBPeripheral] = [:]
    private var found: [UUID: Device] = [:]
    private var writer: CBCharacteristic?
    private var reader: CBCharacteristic?
    private let decoder: BMSDecoder
    private var timer: Timer?
    private var reconnectWork: DispatchWorkItem?
    private var scanTimeout: DispatchWorkItem?
    private var enabled = false
    private var scanRequested = false
    private var writePending = false
    private var connectedAt: TimeInterval?
    private var retryDelay: TimeInterval = 2
    private var disconnecting = Set<UUID>()
    private(set) var status = "未连接 BMS"
    private(set) var sample: ANTBMSSample?
    var onChange: (() -> Void)?
    var onLog: ((String) -> Void)?

    var devices: [Device] {
        found.values.sorted { left, right in
            let leftMatch = Self.looksLike(family, left.name)
            let rightMatch = Self.looksLike(family, right.name)
            if leftMatch != rightMatch { return leftMatch }
            return left.rssi > right.rssi
        }
    }
    var selectedID: UUID? { defaults.string(forKey: "\(family.rawValue)BMSPeripheral").flatMap(UUID.init(uuidString:)) }
    var selectedName: String { defaults.string(forKey: "\(family.rawValue)BMSName") ?? "未选择" }
    var channelHint: String { family.channelHint }
    var familyTitle: String { family.title }
    var freshReading: ANTBMSReading? {
        guard let sample, sample.isFresh(at: ProcessInfo.processInfo.systemUptime) else { return nil }
        return sample.reading
    }

    init(family: BMSFamily = .ant, defaults: UserDefaults = .standard) {
        self.family = family
        self.defaults = defaults
        self.decoder = BMSDecoder(family: family)
        super.init()
        status = "未连接 \(family.short) BMS"
    }

    private static func looksLike(_ family: BMSFamily, _ name: String) -> Bool {
        let upper = name.uppercased()
        return family.namePrefixes.contains { upper.hasPrefix($0) }
    }

    func start() {
        guard !enabled else { return }
        enabled = true
        if central == nil {
            central = CBCentralManager(delegate: self, queue: .main)
        } else if central?.state == .poweredOn {
            connectRememberedOrScan()
        } else {
            update("等待蓝牙可用")
        }
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func stop() {
        enabled = false; scanRequested = false
        timer?.invalidate(); timer = nil
        reconnectWork?.cancel(); reconnectWork = nil
        scanTimeout?.cancel(); scanTimeout = nil
        central?.stopScan()
        clearConnection()
        update("未连接 \(family.short) BMS")
    }

    func scan() {
        guard enabled else { return }
        scanRequested = true
        found.removeAll(); discovered.removeAll()
        beginScan()
    }

    func select(_ id: UUID) {
        guard enabled, let device = found[id] else { return }
        defaults.set(id.uuidString, forKey: "\(family.rawValue)BMSPeripheral")
        defaults.set(device.name, forKey: "\(family.rawValue)BMSName")
        reconnectWork?.cancel(); reconnectWork = nil
        central?.stopScan(); scanRequested = false
        scanTimeout?.cancel(); scanTimeout = nil
        clearConnection()
        retryDelay = 2
        connectRememberedOrScan()
    }

    func forget() {
        clearConnection()
        reconnectWork?.cancel(); reconnectWork = nil
        defaults.removeObject(forKey: "\(family.rawValue)BMSPeripheral")
        defaults.removeObject(forKey: "\(family.rawValue)BMSName")
        if enabled { scan() } else { update("未选择 \(family.short) BMS") }
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state != .poweredOn { disconnecting.removeAll() }
        guard enabled else { return }
        if central.state == .poweredOn {
            if scanRequested { beginScan() } else { connectRememberedOrScan() }
        } else {
            reconnectWork?.cancel(); reconnectWork = nil
            scanTimeout?.cancel(); scanTimeout = nil
            clearConnection()
            disconnecting.removeAll()
            switch central.state {
            case .unauthorized: update("蓝牙权限未允许，请在系统设置中开启")
            case .poweredOff: update("蓝牙已关闭")
            case .unsupported: update("此设备不支持 BMS 蓝牙读取")
            default: update("等待蓝牙可用")
            }
        }
    }

    private func connectRememberedOrScan() {
        guard enabled, let central, central.state == .poweredOn, peripheral == nil else { return }
        guard let id = selectedID else { scan(); return }
        guard !disconnecting.contains(id) else { scheduleReconnect(); return }
        if let target = discovered[id] ?? central.retrievePeripherals(withIdentifiers: [id]).first {
            central.stopScan()
            peripheral = target; target.delegate = self
            connectedAt = ProcessInfo.processInfo.systemUptime
            update("正在连接 \(selectedName)…")
            central.connect(target, options: nil)
        } else {
            scanRequested = true
            beginScan()
        }
    }

    private func beginScan() {
        guard enabled, let central, central.state == .poweredOn else { return }
        scanTimeout?.cancel()
        central.scanForPeripherals(withServices: UIApplication.shared.applicationState == .active
            ? nil : family.serviceUUIDs, options: nil)
        update("正在扫描 \(family.short) BMS…")
        let timeout = DispatchWorkItem { [weak self] in
            guard let self, self.enabled else { return }
            self.central?.stopScan(); self.scanRequested = false
            if self.peripheral == nil {
                self.update(self.found.isEmpty ? "未找到 BMS 设备，请确认蓝牙模块已开启" : "请选择自己的 BMS")
                if self.selectedID != nil { self.scheduleReconnect() }
            }
        }
        scanTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: timeout)
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        guard enabled else { return }
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? peripheral.name ?? "未命名设备"
        discovered[peripheral.identifier] = peripheral
        found[peripheral.identifier] = Device(id: peripheral.identifier, name: name, rssi: RSSI.intValue)
        onChange?()
        if selectedID == peripheral.identifier, self.peripheral == nil { connectRememberedOrScan() }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard enabled, peripheral === self.peripheral else { return }
        update("已连接蓝牙，正在发现 \(family.channelHint) 通道…")
        connectedAt = ProcessInfo.processInfo.systemUptime
        peripheral.discoverServices(family.serviceUUIDs)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "\(family.short) 连接失败")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "\(family.short) 已断开")
    }

    private func disconnected(_ device: CBPeripheral, reason: String) {
        guard device === peripheral else { return }
        clearConnection()
        guard enabled else { return }
        update(reason + "，等待重连")
        scheduleReconnect()
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        let services = peripheral.services ?? []
        guard error == nil,
              let service = services.first(where: { family.serviceUUIDs.contains($0.uuid) }) ?? services.first else {
            failConnection("设备没有可用的 \(family.channelHint) 服务"); return
        }
        peripheral.discoverCharacteristics(nil, for: service)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        let candidates = service.characteristics ?? []
        func writable(_ item: CBCharacteristic) -> Bool {
            item.properties.contains(.write) || item.properties.contains(.writeWithoutResponse)
        }
        func readable(_ item: CBCharacteristic) -> Bool {
            item.properties.contains(.notify) || item.properties.contains(.indicate)
        }
        guard error == nil,
              let writer = candidates.first(where: { $0.uuid == family.writeUUID && writable($0) })
                ?? candidates.first(where: writable),
              let reader = candidates.first(where: { $0.uuid == family.notifyUUID && readable($0) })
                ?? candidates.first(where: readable) else {
            failConnection("设备没有可用的 \(family.short) 收发通道"); return
        }
        self.writer = writer; self.reader = reader
        peripheral.setNotifyValue(true, for: reader)
        update("正在订阅 \(family.short) 实时数据…")
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled else { return }
        guard error == nil, characteristic.isNotifying else { failConnection("\(family.short) 通知订阅失败"); return }
        update("等待首个校验有效的 \(family.short) 实时帧…")
        poll()
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled,
              error == nil, let data = characteristic.value else { return }
        guard let reading = decoder.append(data) else { return }
        sample = ANTBMSSample(reading: reading, uptime: ProcessInfo.processInfo.systemUptime)
        retryDelay = 2
        update("\(family.short) 实时数据已连接")
        onChange?()
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === writer else { return }
        writePending = false
        if let error { failConnection("\(family.short) 读取请求失败：\(error.localizedDescription)") }
    }

    private func tick() {
        guard enabled else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let sample, !sample.isFresh(at: now) {
            update("\(family.short) 数据已过期，等待恢复")
        }
        if let connectedAt, now - (sample?.uptime ?? connectedAt) > 12 {
            failConnection("\(family.short) 未返回有效实时数据，正在重连")
            return
        }
        poll()
        onChange?()
    }

    private func poll() {
        guard enabled, let peripheral, peripheral.state == .connected,
              let writer, reader?.isNotifying == true, !writePending else { return }
        let type: CBCharacteristicWriteType = writer.properties.contains(.write) ? .withResponse : .withoutResponse
        if type == .withoutResponse, !peripheral.canSendWriteWithoutResponse { return }
        let frames = decoder.nextQueries()
        guard let first = frames.first else { return }
        if type == .withResponse {
            writePending = true
            peripheral.writeValue(first, for: writer, type: type)
        } else {
            for frame in frames { peripheral.writeValue(frame, for: writer, type: .withoutResponse) }
        }
    }

    private func failConnection(_ message: String) {
        clearConnection()
        update(message)
        scheduleReconnect()
    }

    private func clearConnection() {
        let previous = peripheral
        peripheral = nil; writer = nil; reader = nil; sample = nil
        connectedAt = nil; writePending = false
        decoder.reset()
        previous?.delegate = nil
        if let previous, previous.state != .disconnected {
            disconnecting.insert(previous.identifier)
            central?.cancelPeripheralConnection(previous)
        }
    }

    private func scheduleReconnect() {
        guard enabled, selectedID != nil, reconnectWork == nil, central?.state == .poweredOn else { return }
        let retry = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.reconnectWork = nil
            self.connectRememberedOrScan()
        }
        reconnectWork = retry
        DispatchQueue.main.asyncAfter(deadline: .now() + retryDelay, execute: retry)
        retryDelay = min(retryDelay * 2, 30)
    }

    private func update(_ text: String) {
        if text != status { status = text; onLog?("\(family.short)：" + text) }
        onChange?()
    }
}
