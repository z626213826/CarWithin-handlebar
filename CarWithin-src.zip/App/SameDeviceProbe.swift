import Foundation

/// Main-queue session for the direct accessory transport.
final class SameDeviceProbe {
    private let transport = DirectAccessoryTransport()
    private var parser = IAP2Parser()
    private var generation = UUID()
    private var active = false
    private var linked = false
    private var authenticated = false
    private var identified = false
    private var sequence: UInt8 = 0x10
    private var acknowledgement: UInt8 = 0
    private var lastPayloadSequence: UInt8?
    private var session: UInt8 = 1
    private var identity: AccessoryIdentity?
    private var configuration: ReceiverConfiguration?
    private var messageBytes = Data()
    private var requested = false
    private var controlConnected = false
    private var expectsLocalControl = true
    /// iOS 已经在同一个 Wi-Fi 上时，会话里的 Wi-Fi 组会让它再尝试加入一次网络；
    /// 密码为空或不对时反而把会话打断，之后就不再连回 7000。默认不带这一组。
    private var attachSessionWiFi = false
    /// 同机场景下 iOS 的 iAP2 链路本来就在 127.0.0.1 上，回连画面端口时也只会认回环地址；
    /// 先按回环请求，15 秒没等到控制连接再改用本机 Wi-Fi 地址试一次。
    private var triedLoopback = false
    private var triedRealAddress = false
    private var originalAddress = ""
    var onLog: ((String) -> Void)?
    var onFinished: ((String) -> Void)?
    var onStage: ((String) -> Void)?

    func start(configuration: ReceiverConfiguration, identity: AccessoryIdentity, expectsLocalControl: Bool = true) {
        stop(); active = true; self.identity = identity; self.configuration = configuration
        self.expectsLocalControl = expectsLocalControl
        // 默认按原始协议把 Wi-Fi 组带上：Wi-Fi 配件告诉 iOS 自己的网络与信道，
        // iOS 才会在 0x4301 之后回连控制端口。关掉它只在"iPhone 已连好且 iOS 不认"时才值得试。
        attachSessionWiFi = UserDefaults.standard.object(forKey: "carPlaySessionWiFi") as? Bool ?? true
        originalAddress = configuration.address
        var initial = configuration
        if (UserDefaults.standard.object(forKey: "sessionLoopback") as? Bool ?? true), initial.address != "127.0.0.1" {
            initial.address = "127.0.0.1"
            self.configuration = initial
            stage(CWL("本机同机会话：先按回环地址 127.0.0.1:{2} 请求 CarPlay（Wi-Fi 地址 {1} 作为备用）",
                      [originalAddress, String(describing: initial.port)]))
        }
        let run = generation
        transport.onData = { [weak self] data in self?.receive(data) }
        do {
            // Use transport type 2 for a Wi-Fi accessory connection.
            try transport.start(withIdentifier: configuration.deviceID, transportType: 2)
            stage(CWL("已创建本机配件端点（传输类型 2），正在建立 iAP2"))
            try transport.send(IAP2Packet.presence)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self, self.active, self.generation == run else { return }
                do {
                    let syn = IAP2Packet(control: 0x80, sequence: self.sequence, acknowledgement: 0, session: 0,
                        payload: Data([1, 5, 8, 0, 7, 0xd0, 0, 0xfa, 3, 3, 1, 0, 1]))
                    try self.transport.send(syn.encoded())
                } catch { self.finish(CWL("本机传输写入失败：{1}", [String(describing: error.localizedDescription)])) }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
                guard let self, self.active, self.generation == run, !self.requested else { return }
                self.finish(CWL("会话启动超时（链路={1}，认证={2}，识别={3}）", [String(describing: self.linked), String(describing: self.authenticated), String(describing: self.identified)]))
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 15) { [weak self] in
                guard let self, self.active, self.generation == run, self.expectsLocalControl,
                      !self.controlConnected, var current = self.configuration else { return }
                if current.address == "127.0.0.1", self.originalAddress != "127.0.0.1", !self.triedRealAddress {
                    self.triedRealAddress = true
                    current.address = self.originalAddress
                    self.configuration = current
                    self.stage(CWL("15 秒未收到控制连接，改用本机 Wi-Fi 地址 {1}:{2} 再请求一次",
                                   [self.originalAddress, String(describing: current.port)]))
                    do { try self.requestSession(current) } catch {
                        self.stage(CWL("改用 Wi-Fi 地址重试失败：{1}", [String(describing: error.localizedDescription)]))
                    }
                    return
                }
                if current.address != "127.0.0.1", !self.triedLoopback {
                    self.triedLoopback = true
                    current.address = "127.0.0.1"
                    self.configuration = current
                    self.stage(CWL("15 秒未收到控制连接，改用 127.0.0.1 再请求一次"))
                    do { try self.requestSession(current) } catch {
                        self.stage(CWL("回环重试失败：{1}", [String(describing: error.localizedDescription)]))
                    }
                    return
                }
                self.stage(CWL("两种地址都没等到控制连接，继续发送画面；仍无画面请回首页重启一次"))
            }
        } catch { finish(CWL("本机传输失败：{1}", [String(describing: error.localizedDescription)])) }
    }
    func stop() {
        active = false; generation = UUID(); transport.stop(); transport.onData = nil; parser = IAP2Parser()
        identity = nil; configuration = nil; messageBytes = Data(); sequence = 0x10; acknowledgement = 0
        session = 1; lastPayloadSequence = nil; linked = false; authenticated = false; identified = false; requested = false; controlConnected = false
    }
    func didConnectControl() {
        guard active else { return }
        controlConnected = true
        stage(CWL("CarPlay 控制连接已建立，正在协商会话"))
    }
    private func requestSession(_ configuration: ReceiverConfiguration) throws {
        var wifi: AccessoryMessages.WiFi?
        if attachSessionWiFi {
            wifi = try AccessoryMessages.WiFi(ssid: configuration.ssid, password: configuration.password,
                                              channel: configuration.wifiChannel)
        }
        stage(CWL("CarPlay 启动会话：{1}:{2}，附带 Wi-Fi 参数={3}", [String(describing: configuration.address),
            String(describing: configuration.port), attachSessionWiFi ? CWL("是") : CWL("否")]))
        try send(AccessoryMessages.startSession(address: configuration.address, port: configuration.port,
            deviceID: configuration.deviceID, wifi: wifi))
    }
    private func stage(_ message: String) { onLog?(message); onStage?(message) }
    private func finish(_ message: String) { onLog?(message); stop(); onFinished?(message) }
    private func ack() throws {
        try transport.send(IAP2Packet(control: 0x40, sequence: sequence, acknowledgement: acknowledgement, session: 0).encoded())
    }
    private func send(_ message: IAP2Message) throws {
        sequence &+= 1
        try transport.send(IAP2Packet(control: 0x40, sequence: sequence, acknowledgement: acknowledgement,
            session: session, payload: message.encoded()).encoded())
        onLog?(String(format: CWL("发送 iAP2 消息 0x%04X"), message.id))
    }
    private func receive(_ data: Data) {
        guard active else { return }
        do {
            for event in try parser.append(data) {
                switch event {
                case .presence: onLog?(CWL("本机 iOS 服务已响应 iAP2 在线探测"))
                case .packet(let packet):
                    acknowledgement = packet.sequence
                    if packet.control & 0x20 != 0 { throw ProtocolError.malformed(CWL("iOS 重置了 iAP2 链路")) }
                    if packet.control & 0x80 != 0 {
                        guard packet.payload.count >= 13 else { throw ProtocolError.malformed(CWL("iAP2 SYN 长度不足")) }
                        session = packet.payload[packet.payload.startIndex + 10]
                        linked = true; try ack(); stage(CWL("本机 iAP2 链路已连接，正在等待配件认证"))
                        continue
                    }
                    guard linked, packet.session == session, !packet.payload.isEmpty else { continue }
                    try ack()
                    if lastPayloadSequence == packet.sequence { continue }
                    lastPayloadSequence = packet.sequence
                    guard messageBytes.count + packet.payload.count <= 65535 else { throw ProtocolError.limitExceeded(CWL("iAP2 控制消息重组")) }
                    messageBytes.append(packet.payload)
                    while messageBytes.count >= 6 {
                        let count = Int(messageBytes[messageBytes.startIndex + 2]) * 256 + Int(messageBytes[messageBytes.startIndex + 3])
                        guard count >= 6 else { throw ProtocolError.malformed(CWL("控制消息长度")) }
                        guard messageBytes.count >= count else { break }
                        let message = try IAP2Message.parse(Data(messageBytes.prefix(count)))
                        messageBytes = Data(messageBytes.dropFirst(count))
                        try handle(message)
                        if !active { return }
                    }
                }
            }
        } catch { finish(CWL("本机配件会话失败：{1}", [String(describing: error.localizedDescription)])) }
    }
    private func handle(_ message: IAP2Message) throws {
        guard let identity, let configuration else { return }
        onLog?(String(format: CWL("收到 iAP2 消息 0x%04X"), message.id))
        switch message.id {
        case 0xaa00:
            try send(IAP2Message(id: 0xaa01, parameters: [IAP2Parameter(id: 0, value: identity.certificateChain)]))
        case 0xaa02:
            guard let challenge = message.parameters.first(where: { $0.id == 0 })?.value else { throw ProtocolError.malformed(CWL("缺少认证挑战")) }
            try send(IAP2Message(id: 0xaa03, parameters: [IAP2Parameter(id: 0, value: identity.sign(challenge: challenge))]))
        case 0xaa04: finish(CWL("iOS 拒绝了配件认证（0xAA04）"))
        case 0xaa05: authenticated = true; stage(CWL("iOS 已接受配件认证"))
        case 0x1d00: try send(AccessoryMessages.identification(name: configuration.name, deviceID: configuration.deviceID))
        case 0x1d02: identified = true; stage(CWL("iOS 已接受配件识别，正在等待 CarPlay 可用通知"))
        case 0x1d03:
            let rejected = message.parameters.map { String(format: "%04X:%@", $0.id, $0.value.prefix(32).map { String(format: "%02X", $0) }.joined()) }.joined(separator: ",")
            finish(CWL("iOS 拒绝了配件识别（0x1D03）：{1}", [String(describing: rejected)]))
        case 0x4300:
            guard authenticated, identified else { throw ProtocolError.malformed(CWL("认证或识别完成前收到 CarPlay 可用通知")) }
            for group in message.parameters {
                let nested = try IAP2Parameter.parse(group.value)
                if let value = nested.first(where: { $0.id == 0 })?.value.first {
                    onLog?(CWL("CarPlay 可用传输 {1}：{2}", [String(describing: group.id), String(describing: value)]))
                }
            }
            // 控制端口先连上并不代表会话已开：0x4301（开始 CarPlay）仍要发给主机，
            // 否则主机只在协商阶段空等。
            if !expectsLocalControl && requested { return }
            try requestSession(configuration)
            if !requested && expectsLocalControl {
                let run = generation
                for delay in [3.0, 6.0, 9.0] {
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                        guard let self, self.active, self.generation == run, !self.controlConnected else { return }
                        do { try self.requestSession(configuration) }
                        catch { self.finish(CWL("会话重试失败：{1}", [String(describing: error)])) }
                    }
                }
            }
            requested = true
            stage(expectsLocalControl
                ? CWL("已请求在 {1}:{2} 启动 CarPlay，会话正在等待 TCP 连接", [String(describing: configuration.address), String(describing: configuration.port)])
                : CWL("已向 {1}（{2}:{3}）请求 CarPlay。请保持此 App 运行并查看 iPad 画面。", [String(describing: configuration.name), String(describing: configuration.address), String(describing: configuration.port)]))
        default: onLog?(String(format: CWL("未处理的配件消息 0x%04X"), message.id))
        }
    }
}
