import AVFoundation
import MediaPlayer
import UIKit

/// 车把滚轮在九号仪表固件里是"媒体音量键"和"切歌键"，事件落在 iOS 的媒体层。
/// 系统音量变化 App 是能读到的，切歌命令也能通过 MPRemoteCommandCenter 接管，
/// 因此这两类事件可以在 App 内重新翻译成 CarPlay 的旋钮上/下，驱动投屏菜单焦点。
final class VolumeKeyBridge {
    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    private var observation: NSKeyValueObservation?
    private var mediaTargets: [Any] = []
    private var baseVolume: Float = 0
    private var lastTrigger: TimeInterval = -.infinity
    private let volumeView = MPVolumeView(frame: CGRect(x: -240, y: -240, width: 20, height: 20))
    private var started = false

    /// 一次滚轮可能会连续改变几格音量，只认第一下，避免焦点连跳。
    private func trigger(_ control: CarPlayControl, label: String) {
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastTrigger >= 0.18 else { return }
        lastTrigger = now
        onLog?(CWL("滚轮{1} → {2}", [label, control.title]))
        onControl?(control)
    }

    func start(in host: UIView) {
        guard !started else { return }
        started = true
        let session = AVAudioSession.sharedInstance()
        baseVolume = session.outputVolume
        volumeView.alpha = 0.01
        volumeView.showsVolumeSlider = true
        host.addSubview(volumeView)

        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] session, _ in
            guard let self, self.started else { return }
            let value = session.outputVolume
            guard abs(value - self.baseVolume) >= 0.005 else { return }
            self.trigger(value > self.baseVolume ? .knobNext : .knobPrevious, label: CWL("音量键"))
            // 立刻把系统音量放回原位，滚轮就只负责翻页，不会把音量调到最大或最小。
            self.restoreVolume()
        }

        let center = MPRemoteCommandCenter.shared()
        center.nextTrackCommand.isEnabled = true
        center.previousTrackCommand.isEnabled = true
        let next = center.nextTrackCommand.addTarget { [weak self] _ in
            self?.trigger(.knobNext, label: CWL("切歌键"))
            return .success
        }
        let previous = center.previousTrackCommand.addTarget { [weak self] _ in
            self?.trigger(.knobPrevious, label: CWL("切歌键"))
            return .success
        }
        mediaTargets = [next, previous]
        onLog?(CWL("车把滚轮已接管：音量键与切歌键都转成投屏菜单的上一项/下一项"))
    }

    func stop() {
        guard started else { return }
        started = false
        observation = nil
        let center = MPRemoteCommandCenter.shared()
        for target in mediaTargets { center.nextTrackCommand.removeTarget(target); center.previousTrackCommand.removeTarget(target) }
        mediaTargets = []
        volumeView.removeFromSuperview()
    }

    private func restoreVolume() {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.started else { return }
            for sub in self.volumeView.subviews {
                guard let slider = sub as? UISlider else { continue }
                if abs(slider.value - self.baseVolume) > 0.005 { slider.setValue(self.baseVolume, animated: false) }
                break
            }
        }
    }
}
