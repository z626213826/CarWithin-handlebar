import AVFoundation
import MediaPlayer
import UIKit

/// 车把滚轮在九号仪表固件里是媒体键：上下=音量，左右=切歌，按下=播放/暂停。
/// CarPlay 本身感知不到这些，所以 App 在这里全部接管，翻译成 CarPlay 的旋钮动作：
///   音量上 / 下一曲 / 快进  → 菜单焦点下一项
///   音量下 / 上一曲 / 快退  → 菜单焦点上一项
///   播放 / 暂停 / 停止      → 选择（进入当前焦点所在的 App）
///
/// 两个关键点：
/// 1. 方向必须按"和上一次的音量差"判，不能拿一个固定基准（比如 0.5）去比。
///    系统音量卡在 100% 或很低时，固定基准会让上滚、下滚都被判成同一个方向。
/// 2. 播放/暂停键只有在本 App 真的在播放音频时才会被系统路由过来，
///    所以这里挂一段 0 音量的循环音频，把自己坐实成"正在播放"。
final class VolumeKeyBridge {
    /// AppDelegate 收到 AVRCP 老通道的按键时，转给这里。
    static weak var shared: VolumeKeyBridge?

    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    /// 上下方向反了时置 true（滚上=上一项）。
    var reversed = false

    private var observation: NSKeyValueObservation?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var lastTrigger: TimeInterval = -.infinity
    private var lastVolume: Float = 0.5
    private var ignoreUntil: TimeInterval = 0
    private let volumeView = MPVolumeView(frame: CGRect(x: -240, y: -240, width: 20, height: 20))
    private var silence: AVAudioPlayer?
    private var started = false

    private var slider: UISlider? {
        volumeView.subviews.compactMap { $0 as? UISlider }.first
    }

    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    /// 一次滚轮会连发几格，只认第一下，避免焦点连跳。
    /// 按下允许连发（双击 = 两次选择），所以门槛比翻页短。
    private func trigger(_ control: CarPlayControl, label: String, gate: TimeInterval = 0.22) {
        let t = now
        guard t - lastTrigger >= gate else { return }
        lastTrigger = t
        onLog?(CWL("滚轮{1} → {2}", [label, control.title]))
        onControl?(control)
    }

    private func stepped(_ forward: Bool, label: String) {
        let up = reversed ? !forward : forward
        trigger(up ? .knobNext : .knobPrevious, label: label)
    }

    func start(in host: UIView) {
        guard !started else { return }
        started = true
        VolumeKeyBridge.shared = self
        UIApplication.shared.beginReceivingRemoteControlEvents()
        let session = AVAudioSession.sharedInstance()
        let original = session.outputVolume
        lastVolume = original

        volumeView.alpha = 0.01
        volumeView.showsRouteButton = false
        host.addSubview(volumeView)

        onLog?(CWL("车把滚轮接管启动：系统音量 {1}（按相邻两次变化判方向）",
                    [String(format: "%.2f", original)]))

        var sessionNote = "未激活"
        do {
            // 独占 playback（不混音）：混音模式下系统不把本 App 当作主播放器，
            // 车机的播放/暂停键就不会路由过来。
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true, options: [])
            sessionNote = "已激活（独占）"
        } catch {
            sessionNote = "激活失败：\(error.localizedDescription)"
        }
        startSilenceLoop()
        MPNowPlayingInfoCenter.default().playbackState = .playing
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: CWL("CarWithin 投屏"),
            MPMediaItemPropertyPlaybackDuration: 0.0,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: 0.0,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyIsLiveStream: true
        ]
        onLog?(CWL("媒体键接管：音频会话{1}，静音循环{2}，播放状态=正在播放",
                    [sessionNote, silence?.isPlaying == true ? CWL("已启动") : CWL("未启动")]))

        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] _, _ in
            guard let self, self.started else { return }
            let t = self.now
            guard t >= self.ignoreUntil else { return }
            let value = session.outputVolume
            let delta = value - self.lastVolume
            self.lastVolume = value
            guard abs(delta) >= 0.01 else { return }
            self.stepped(delta > 0, label: CWL("音量键"))
            self.onLog?(CWL("音量 {1} → {2}", [String(format: "%.2f", value),
                                             delta > 0 ? CWL("下一项") : CWL("上一项")]))
            self.ignoreUntil = t + 0.20
            // 贴边就顺手拉回中位，能给 slider 赋值就赋，赋不了也不影响判断。
            if value <= 0.12 || value >= 0.88 { self.recenter(after: 0.05) }
        }

        let center = MPRemoteCommandCenter.shared()
        attach(center.nextTrackCommand) { [weak self] in self?.stepped(true, label: CWL("下一曲键")) }
        attach(center.previousTrackCommand) { [weak self] in self?.stepped(false, label: CWL("上一曲键")) }
        attach(center.seekForwardCommand) { [weak self] in self?.stepped(true, label: CWL("快进键")) }
        attach(center.seekBackwardCommand) { [weak self] in self?.stepped(false, label: CWL("快退键")) }
        attach(center.playCommand) { [weak self] in self?.trigger(.select, label: CWL("播放键"), gate: 0.1) }
        attach(center.pauseCommand) { [weak self] in self?.trigger(.select, label: CWL("暂停键"), gate: 0.1) }
        attach(center.togglePlayPauseCommand) { [weak self] in self?.trigger(.select, label: CWL("播放暂停键"), gate: 0.1) }
        attach(center.stopCommand) { [weak self] in self?.trigger(.select, label: CWL("停止键"), gate: 0.1) }

        onLog?(CWL("媒体键命令已接管：播放/暂停/停止 → 选择（方向{1}）",
                    [reversed ? CWL("已反转") : CWL("默认")]))
    }

    /// AVRCP 老通道的按键（AppDelegate 转进来）。
    @discardableResult
    func handleRemote(_ subtype: UIEvent.EventSubtype) -> Bool {
        guard started else { return false }
        switch subtype {
        case .remoteControlPlay, .remoteControlPause, .remoteControlTogglePlayPause, .remoteControlStop:
            trigger(.select, label: CWL("车机媒体键"), gate: 0.15)
        case .remoteControlNextTrack:
            stepped(true, label: CWL("车机下一曲键"))
        case .remoteControlPreviousTrack:
            stepped(false, label: CWL("车机上一曲键"))
        default:
            return false
        }
        return true
    }

    /// 0 音量的循环音频：系统判断"谁在放声音"时才会把车机的播放键交给我们。
    private func startSilenceLoop() {
        let sampleRate = 8000
        let frames = sampleRate / 4
        let pcm = Data(count: frames * 2)
        var wav = Data()
        func le16(_ v: UInt16) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff)] }
        func le32(_ v: UInt32) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff),
                                             UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)] }
        wav.append(contentsOf: [0x52, 0x49, 0x46, 0x46])
        wav.append(contentsOf: le32(UInt32(36 + pcm.count)))
        wav.append(contentsOf: [0x57, 0x41, 0x56, 0x45, 0x66, 0x6d, 0x74, 0x20])
        wav.append(contentsOf: le32(16))
        wav.append(contentsOf: le16(1))
        wav.append(contentsOf: le16(1))
        wav.append(contentsOf: le32(UInt32(sampleRate)))
        wav.append(contentsOf: le32(UInt32(sampleRate) * 4))
        wav.append(contentsOf: le16(2))
        wav.append(contentsOf: le16(16))
        wav.append(contentsOf: [0x64, 0x61, 0x74, 0x61])
        wav.append(contentsOf: le32(UInt32(pcm.count)))
        wav.append(pcm)
        do {
            let player = try AVAudioPlayer(data: wav)
            player.numberOfLoops = -1
            player.volume = 0.03
            player.prepareToPlay()
            player.play()
            silence = player
        } catch {
            onLog?(CWL("静音循环启动失败：{1}", [error.localizedDescription]))
        }
    }

    private func recenter(after delay: TimeInterval) {
        ignoreUntil = max(ignoreUntil, now + delay + 0.45)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self, self.started else { return }
            if let slider = self.slider, abs(slider.value - 0.5) > 0.02 {
                slider.setValue(0.5, animated: false)
                self.onLog?(CWL("音量贴边，已拉回 0.50"))
            }
            self.lastVolume = AVAudioSession.sharedInstance().outputVolume
        }
    }

    private func attach(_ command: MPRemoteCommand, action: @escaping () -> Void) {
        command.isEnabled = true
        let target = command.addTarget { _ in action(); return .success }
        targets.append((command, target))
    }

    func stop() {
        guard started else { return }
        started = false
        observation = nil
        silence?.stop()
        silence = nil
        for (command, target) in targets {
            command.removeTarget(target)
            command.isEnabled = false
        }
        targets = []
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        MPNowPlayingInfoCenter.default().playbackState = .stopped
        volumeView.removeFromSuperview()
        if VolumeKeyBridge.shared === self { VolumeKeyBridge.shared = nil }
    }
}
