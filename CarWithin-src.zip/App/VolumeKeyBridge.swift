import AVFoundation
import MediaPlayer
import UIKit

/// 车把滚轮在九号仪表固件里是媒体键：上下=音量，左右=切歌，按下=播放/暂停。
/// CarPlay 本身感知不到这些，所以 App 在这里全部接管，翻译成 CarPlay 的旋钮动作：
///   音量上 / 下一曲 / 快进  → 菜单焦点下一项
///   音量下 / 上一曲 / 快退  → 菜单焦点上一项
///   播放 / 暂停 / 停止      → 选择（进入当前焦点所在的 App）
///
/// 两个关键点：
/// 1. 方向必须按"和上一次的音量差"判，不能拿一个固定基准（比如 0.5）去比。
///    系统音量卡在 100% 或很低时，固定基准会让上滚、下滚都被判成同一个方向。
/// 2. 播放/暂停键只有在本 App 真的在播放音频时才会被系统路由过来，
///    所以这里挂一段 0 音量的循环音频，把自己坐实成"正在播放"。
final class VolumeKeyBridge {
    /// AppDelegate 收到 AVRCP 老通道的按键时，转给这里。
    static weak var shared: VolumeKeyBridge?

    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    /// 上下方向反了时置 true（滚上=上一项）。
    var reversed = false
    /// 上下滚轮（音量键）是否用来翻页。关掉就还给系统调音量。
    var verticalPaging = true
    /// 左右滚轮（切歌键）是否用来翻页。
    var horizontalPaging = true
    /// 滚轮停住一会儿自动选中（仪表不把"按下"发给手机，这是替代方案）。
    var autoSelectDelay: TimeInterval = 1.6
    private var autoSelectWork: DispatchWorkItem?

    private var observation: NSKeyValueObservation?
    private var pollTimer: Timer?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var lastTrigger: TimeInterval = -.infinity
    private var lastVolume: Float = 0.5
    private var ignoreUntil: TimeInterval = 0
    private let volumeView = MPVolumeView(frame: CGRect(x: -240, y: -240, width: 20, height: 20))
    private var silence: AVAudioPlayer?
    private var started = false

    private var slider: UISlider? {
        volumeView.subviews.compactMap { $0 as? UISlider }.first
    }

    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    /// 一次滚轮会连发几格，只认第一下，避免焦点连跳。
    /// 按下允许连发（双击 = 两次选择），所以门槛比翻页短。
    @discardableResult
    private func trigger(_ control: CarPlayControl, label: String, gate: TimeInterval = 0.09) -> Bool {
        let t = now
        guard t - lastTrigger >= gate else { return false }
        lastTrigger = t
        onLog?(CWL("滚轮{1} → {2}", [label, control.title]))
        onControl?(control)
        return true
    }

    /// 翻页后开始计时：停住不动 autoSelectDelay 秒，就替用户发一次"选择"。
    private func scheduleAutoSelect() {
        guard autoSelectDelay > 0 else { return }
        autoSelectWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self, self.started else { return }
            self.onLog?(CWL("滚轮停住 {1}s，自动选中焦点（替代按下键）",
                            [String(format: "%.1f", self.autoSelectDelay)]))
            _ = self.trigger(.select, label: CWL("停顿自动选择"), gate: 0.6)
        }
        autoSelectWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + autoSelectDelay, execute: work)
        onLog?(CWL("停住不动 {1}s 自动选中", [String(format: "%.1f", autoSelectDelay)]))
    }

    private func stepped(_ forward: Bool, label: String) {
        let up = reversed ? !forward : forward
        if trigger(up ? .knobNext : .knobPrevious, label: label) { scheduleAutoSelect() }
    }

    func start(in host: UIView) {
        guard !started else { return }
        started = true
        VolumeKeyBridge.shared = self
        UIApplication.shared.beginReceivingRemoteControlEvents()
        let session = AVAudioSession.sharedInstance()
        let original = session.outputVolume
        lastVolume = original

        volumeView.alpha = 0.01
        volumeView.showsRouteButton = false
        host.addSubview(volumeView)

        onLog?(CWL("车把滚轮接管启动：系统音量 {1}（按相邻两次变化判方向）",
                    [String(format: "%.2f", original)]))

        // 不再激活音频会话、不再挂静音音频：独占播放会让 iPhone 把音频路由
        // 揽到本 App 上，仪表那边就只看到一条"CarWithin 投屏"的媒体卡片，
        // CarPlay 画面反而起不来。滚轮上下走的是系统音量变化，不需要会话。
        onLog?(CWL("滚轮接管：只监听音量，不占用音频会话（避免影响 CarPlay 会话）"))

        // 系统音量变化不一定每次都回调（没在放歌时尤其少），再挂一个 25ms 的轮询兜底，
        // 两路都送到 handleVolume(_:)，值没变就忽略，不会重复翻页。
        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] _, _ in
            self?.handleVolume(session.outputVolume)
        }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.025, repeats: true) { [weak self] _ in
            self?.handleVolume(AVAudioSession.sharedInstance().outputVolume)
        }
        if let pollTimer { RunLoop.main.add(pollTimer, forMode: .common) }

        let center = MPRemoteCommandCenter.shared()
        attach(center.nextTrackCommand) { [weak self] in self?.side(true, label: CWL("左右滚轮")) }
        attach(center.previousTrackCommand) { [weak self] in self?.side(false, label: CWL("左右滚轮")) }
        attach(center.seekForwardCommand) { [weak self] in self?.side(true, label: CWL("左右滚轮")) }
        attach(center.seekBackwardCommand) { [weak self] in self?.side(false, label: CWL("左右滚轮")) }
        attach(center.playCommand) { [weak self] in self?.trigger(.select, label: CWL("播放键"), gate: 0.1) }
        attach(center.pauseCommand) { [weak self] in self?.trigger(.select, label: CWL("暂停键"), gate: 0.1) }
        attach(center.togglePlayPauseCommand) { [weak self] in self?.trigger(.select, label: CWL("播放暂停键"), gate: 0.1) }
        attach(center.stopCommand) { [weak self] in self?.trigger(.select, label: CWL("停止键"), gate: 0.1) }

        onLog?(CWL("媒体键命令已接管：左右滚轮=翻页（{1}），上下滚轮=翻页（{2}），播放/暂停=选择（方向{3}）",
                    [horizontalPaging ? CWL("开") : CWL("关"),
                     verticalPaging ? CWL("开") : CWL("关"),
                     reversed ? CWL("已反转") : CWL("默认")]))
    }

    /// 音量变化的统一入口：KVO 和轮询都走这里，按"和上一次的差值"判方向。
    private func handleVolume(_ value: Float) {
        guard started, verticalPaging else { return }
        let t = now
        let delta = value - lastVolume
        guard abs(delta) >= 0.01 else { return }
        lastVolume = value
        // 刚做过回中（程序改的音量）不当事，避免回中本身被当成滚动。
        guard t >= ignoreUntil else { return }
        stepped(delta > 0, label: CWL("上下滚轮"))
        onLog?(CWL("音量 {1} → {2}", [String(format: "%.2f", value),
                              delta > 0 ? CWL("下一项") : CWL("上一项")]))
        // 贴近两端时每一格都可能不再"变化"，滚到头就没反应；提前拉回中位，保证两头都有余量。
        if value <= 0.20 || value >= 0.80 { recenter(after: 0.04) }
    }

    /// 左右滚轮（系统里的下一曲/上一曲）→ 翻页。左右不受"上下方向反转"影响。
    private func side(_ forward: Bool, label: String) {
        guard horizontalPaging else {
            onLog?(CWL("左右滚轮事件到达，但「左右滚轮翻页」是关的"))
            return
        }
        if trigger(forward ? .knobNext : .knobPrevious, label: label) { scheduleAutoSelect() }
    }

    /// AVRCP 老通道的按键（AppDelegate 转进来）。
    @discardableResult
    func handleRemote(_ subtype: UIEvent.EventSubtype) -> Bool {
        guard started else { return false }
        switch subtype {
        case .remoteControlPlay, .remoteControlPause, .remoteControlTogglePlayPause, .remoteControlStop:
            trigger(.select, label: CWL("车机媒体键"), gate: 0.15)
        case .remoteControlNextTrack:
            side(true, label: CWL("车机左右滚轮"))
        case .remoteControlPreviousTrack:
            side(false, label: CWL("车机左右滚轮"))
        default:
            return false
        }
        return true
    }

    /// 0 音量的循环音频：系统判断"谁在放声音"时才会把车机的播放键交给我们。
    private func startSilenceLoop() {
        let sampleRate = 8000
        let frames = sampleRate / 4
        let pcm = Data(count: frames * 2)
        var wav = Data()
        func le16(_ v: UInt16) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff)] }
        func le32(_ v: UInt32) -> [UInt8] { [UInt8(v & 0xff), UInt8((v >> 8) & 0xff),
                                             UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)] }
        wav.append(contentsOf: [0x52, 0x49, 0x46, 0x46])
        wav.append(contentsOf: le32(UInt32(36 + pcm.count)))
        wav.append(contentsOf: [0x57, 0x41, 0x56, 0x45, 0x66, 0x6d, 0x74, 0x20])
        wav.append(contentsOf: le32(16))
        wav.append(contentsOf: le16(1))
        wav.append(contentsOf: le16(1))
        wav.append(contentsOf: le32(UInt32(sampleRate)))
        wav.append(contentsOf: le32(UInt32(sampleRate) * 4))
        wav.append(contentsOf: le16(2))
        wav.append(contentsOf: le16(16))
        wav.append(contentsOf: [0x64, 0x61, 0x74, 0x61])
        wav.append(contentsOf: le32(UInt32(pcm.count)))
        wav.append(pcm)
        do {
            let player = try AVAudioPlayer(data: wav)
            player.numberOfLoops = -1
            player.volume = 0.03
            player.prepareToPlay()
            player.play()
            silence = player
        } catch {
            onLog?(CWL("静音循环启动失败：{1}", [error.localizedDescription]))
        }
    }

    private func recenter(after delay: TimeInterval) {
        ignoreUntil = max(ignoreUntil, now + delay + 0.45)
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            guard let self, self.started else { return }
            if let slider = self.slider, abs(slider.value - 0.5) > 0.02 {
                slider.setValue(0.5, animated: false)
                self.onLog?(CWL("音量贴边，已拉回 0.50"))
            }
            self.lastVolume = AVAudioSession.sharedInstance().outputVolume
        }
    }

    private func attach(_ command: MPRemoteCommand, action: @escaping () -> Void) {
        command.isEnabled = true
        let target = command.addTarget { _ in action(); return .success }
        targets.append((command, target))
    }

    func stop() {
        guard started else { return }
        started = false
        observation = nil
        pollTimer?.invalidate(); pollTimer = nil
        silence?.stop()
        silence = nil
        for (command, target) in targets {
            command.removeTarget(target)
            command.isEnabled = false
        }
        targets = []
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        MPNowPlayingInfoCenter.default().playbackState = .stopped
        volumeView.removeFromSuperview()
        if VolumeKeyBridge.shared === self { VolumeKeyBridge.shared = nil }
    }
}
