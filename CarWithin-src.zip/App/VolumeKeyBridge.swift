import AVFoundation
import MediaPlayer
import UIKit

/// 车把滚轮在九号仪表固件里是媒体键：上下=音量，左右=切歌，按下=播放/暂停。
/// 这些事件落在 iOS 的媒体层，CarPlay 本身感知不到，所以 App 在这里把它们
/// 全部接管，翻译成 CarPlay 的旋钮动作：
///   音量上 / 下一曲 / 快进  → 菜单焦点下一项
///   音量下 / 上一曲 / 快退  → 菜单焦点上一项
///   播放 / 暂停 / 播放暂停  → 选择（进入当前焦点所在的 App）
/// 为了让系统把这些键路由给本 App，需要把自己登记成"正在播放"的 App。
///
/// 关键：系统音量卡在 100% 时"上滚"没有任何变化，只有"下滚"能触发，
/// 结果就是永远只能发「上一项」。所以启动时先把音量对齐到中位，
/// 之后每次翻页都把音量送回中位，保证上下两个方向都留有余量。
final class VolumeKeyBridge {
    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    /// 上下方向反了时置 true（滚上=上一项）。
    var reversed = false

    private var observation: NSKeyValueObservation?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var lastTrigger: TimeInterval = -.infinity
    /// 音量基准点：钉在中位，上下各留一半行程。
    private let neutral: Float = 0.5
    /// 这之前收到的音量回调一律忽略（复位、对齐基准自己造成的变化）。
    private var ignoreUntil: TimeInterval = 0
    private let volumeView = MPVolumeView(frame: CGRect(x: -240, y: -240, width: 20, height: 20))
    private var started = false

    private var slider: UISlider? {
        volumeView.subviews.compactMap { $0 as? UISlider }.first
    }

    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    /// 一次滚轮会连发几格，只认第一下，避免焦点连跳。
    private func trigger(_ control: CarPlayControl, label: String) {
        let t = now
        guard t - lastTrigger >= 0.22 else { return }
        lastTrigger = t
        onLog?(CWL("滚轮{1} → {2}", [label, control.title]))
        onControl?(control)
    }

    private func stepped(_ forward: Bool, label: String) {
        let up = reversed ? !forward : forward
        trigger(up ? .knobNext : .knobPrevious, label: label)
    }

    func start(in host: UIView) {
        guard !started else { return }
        started = true
        let session = AVAudioSession.sharedInstance()
        let original = session.outputVolume
        volumeView.alpha = 0.01
        volumeView.showsRouteButton = false
        host.addSubview(volumeView)
        onLog?(CWL("车把滚轮接管启动：系统音量 {1}，基准对齐到 {2}",
                    [String(format: "%.2f", original), String(format: "%.2f", neutral)]))
        ignoreUntil = now + 0.8
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            self?.snapToNeutral()
        }

        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] _, _ in
            guard let self, self.started else { return }
            let t = self.now
            guard t >= self.ignoreUntil else { return }
            let value = session.outputVolume
            let delta = value - self.neutral
            guard abs(delta) >= 0.02 else { return }
            self.stepped(delta > 0, label: CWL("音量键"))
            self.onLog?(CWL("音量 {1} → 基准", [String(format: "%.2f", value)]))
            self.ignoreUntil = t + 0.26
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
                self?.snapToNeutral()
            }
        }

        // 登记成"正在播放"的 App，系统才会把车机的媒体键发给这里。
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: CWL("CarWithin 投屏"),
            MPNowPlayingInfoPropertyPlaybackRate: 0.0
        ]

        let center = MPRemoteCommandCenter.shared()
        attach(center.nextTrackCommand) { [weak self] in self?.stepped(true, label: CWL("下一曲键")) }
        attach(center.previousTrackCommand) { [weak self] in self?.stepped(false, label: CWL("上一曲键")) }
        attach(center.seekForwardCommand) { [weak self] in self?.stepped(true, label: CWL("快进键")) }
        attach(center.seekBackwardCommand) { [weak self] in self?.stepped(false, label: CWL("快退键")) }
        attach(center.playCommand) { [weak self] in self?.trigger(.select, label: CWL("播放键")) }
        attach(center.pauseCommand) { [weak self] in self?.trigger(.select, label: CWL("暂停键")) }
        attach(center.togglePlayPauseCommand) { [weak self] in self?.trigger(.select, label: CWL("播放暂停键")) }

        onLog?(CWL("车把滚轮已接管：上下=翻页，左右=翻页，按下=选择（方向{1}）",
                    [reversed ? CWL("已反转") : CWL("默认")]))
    }

    private func snapToNeutral() {
        guard started, let slider else { return }
        if abs(slider.value - neutral) > 0.01 {
            ignoreUntil = max(ignoreUntil, now + 0.2)
            slider.setValue(neutral, animated: false)
        }
    }

    private func attach(_ command: MPRemoteCommand, action: @escaping () -> Void) {
        command.isEnabled = true
        let target = command.addTarget { _ in action(); return .success }
        targets.append((command, target))
    }

    func stop() {
        guard started else { return }
        started = false
        observation = nil
        for (command, target) in targets {
            command.removeTarget(target)
            command.isEnabled = false
        }
        targets = []
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        volumeView.removeFromSuperview()
    }
}
