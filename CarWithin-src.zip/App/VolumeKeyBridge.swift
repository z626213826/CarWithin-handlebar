import AVFoundation
import MediaPlayer
import UIKit

/// 车把滚轮在九号仪表固件里是媒体键：上下=音量，左右=切歌，按下=播放/暂停。
/// 这些事件落在 iOS 的媒体层，CarPlay 本身感知不到，所以 App 在这里把它们
/// 全部接管，翻译成 CarPlay 的旋钮动作：
///   音量上 / 下一曲 / 快进  → 菜单焦点下一项
///   音量下 / 上一曲 / 快退  → 菜单焦点上一项
///   播放 / 暂停 / 播放暂停  → 选择（进入当前焦点所在的 App）
/// 为了让系统把这些键路由给本 App，需要把自己登记成"正在播放"的 App。
final class VolumeKeyBridge {
    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    /// 上下方向反了时置 true（滚上=上一项）。
    var reversed = false

    private var observation: NSKeyValueObservation?
    private var targets: [(MPRemoteCommand, Any)] = []
    private var baseVolume: Float = 0
    private var lastTrigger: TimeInterval = -.infinity
    private let volumeView = MPVolumeView(frame: CGRect(x: -240, y: -240, width: 20, height: 20))
    private var started = false

    /// 一次滚轮会连发几格，只认第一下，避免焦点连跳。
    private func trigger(_ control: CarPlayControl, label: String) {
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastTrigger >= 0.16 else { return }
        lastTrigger = now
        onLog?(CWL("滚轮{1} → {2}", [label, control.title]))
        onControl?(control)
    }

    private func stepped(_ forward: Bool, label: String) {
        let up = reversed ? !forward : forward
        trigger(up ? .knobNext : .knobPrevious, label: label)
    }

    func start(in host: UIView) {
        guard !started else { return }
        started = true
        let session = AVAudioSession.sharedInstance()
        baseVolume = session.outputVolume
        volumeView.alpha = 0.01
        host.addSubview(volumeView)

        observation = session.observe(\.outputVolume, options: [.new]) { [weak self] session, _ in
            guard let self, self.started else { return }
            let value = session.outputVolume
            guard abs(value - self.baseVolume) >= 0.005 else { return }
            self.stepped(value > self.baseVolume, label: CWL("音量键"))
            // 把系统音量放回原位：滚轮只负责翻页，不会把音量调到顶或底。
            self.restoreVolume()
        }

        // 登记成"正在播放"的 App，系统才会把车机的媒体键发给这里。
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: CWL("CarWithin 投屏"),
            MPNowPlayingInfoPropertyPlaybackRate: 0.0
        ]

        let center = MPRemoteCommandCenter.shared()
        attach(center.nextTrackCommand) { [weak self] in self?.stepped(false, label: CWL("下一曲键")) }
        attach(center.previousTrackCommand) { [weak self] in self?.stepped(true, label: CWL("上一曲键")) }
        attach(center.seekForwardCommand) { [weak self] in self?.stepped(false, label: CWL("快进键")) }
        attach(center.seekBackwardCommand) { [weak self] in self?.stepped(true, label: CWL("快退键")) }
        attach(center.playCommand) { [weak self] in self?.trigger(.select, label: CWL("播放键")) }
        attach(center.pauseCommand) { [weak self] in self?.trigger(.select, label: CWL("暂停键")) }
        attach(center.togglePlayPauseCommand) { [weak self] in self?.trigger(.select, label: CWL("播放暂停键")) }

        onLog?(CWL("车把滚轮已接管：上下=翻页，左右=翻页，按下=选择（方向{1}）",
                    [reversed ? CWL("已反转") : CWL("默认")]))
    }

    private func attach(_ command: MPRemoteCommand, action: @escaping () -> Void) {
        command.isEnabled = true
        let target = command.addTarget { _ in action(); return .success }
        targets.append((command, target))
    }

    func stop() {
        guard started else { return }
        started = false
        observation = nil
        for (command, target) in targets {
            command.removeTarget(target)
            command.isEnabled = false
        }
        targets = []
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        volumeView.removeFromSuperview()
    }

    private func restoreVolume() {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.started else { return }
            for sub in self.volumeView.subviews {
                guard let slider = sub as? UISlider else { continue }
                if abs(slider.value - self.baseVolume) > 0.005 { slider.setValue(self.baseVolume, animated: false) }
                break
            }
        }
    }
}
