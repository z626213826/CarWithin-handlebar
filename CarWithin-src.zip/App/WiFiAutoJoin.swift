import NetworkExtension
import UIKit

/// 让 App 自己去连 Wi-Fi。
/// iOS 不允许第三方 App 枚举周围的 Wi-Fi 列表（没有任何公开接口可以扫），
/// 但允许按"名字"或"名字前缀"去加入一个已知网络，九号的仪表热点都是
/// DIRECT- 开头，所以用前缀就能自动连上，不用扫描。
final class WiFiAutoJoin {
    static let shared = WiFiAutoJoin()
    private var busy = false

    /// ssidPrefix 优先：九号热点的名字后半段每台都不一样，用前缀最省事。
    func join(ssidPrefix: String? = nil, ssid: String, password: String,
              log: @escaping (String) -> Void, done: ((Bool) -> Void)? = nil) {
        guard !busy else { log(CWL("上一次自动连接还在进行，稍等一下")); return }
        let trimmedPrefix = ssidPrefix?.trimmingCharacters(in: .whitespaces) ?? ""
        let trimmedSSID = ssid.trimmingCharacters(in: .whitespaces)
        guard !trimmedPrefix.isEmpty || !trimmedSSID.isEmpty else {
            log(CWL("先填 Wi-Fi 名称，或用「自动连接仪表热点」")); done?(false); return
        }
        busy = true
        let config: NEHotspotConfiguration
        if !trimmedPrefix.isEmpty {
            config = NEHotspotConfiguration(ssidPrefix: trimmedPrefix)
        } else {
            config = NEHotspotConfiguration(ssid: trimmedSSID, passphrase: password, isWEP: false)
        }
        config.joinOnce = false
        NEHotspotConfigurationManager.shared.apply(config) { [weak self] error in
            DispatchQueue.main.async {
                self?.busy = false
                if let error = error as NSError? {
                    if error.code == NEHotspotConfigurationError.alreadyAssociated.rawValue {
                        log(CWL("这个 Wi-Fi 已经连上了")); done?(true); return
                    }
                    log(CWL("自动连接失败（{1}）：{2}。可以点「打开系统 Wi-Fi 设置」手动连。",
                            [String(error.code), error.localizedDescription]))
                    done?(false)
                    return
                }
                log(CWL("已自动连上 Wi-Fi：{1}", [trimmedPrefix.isEmpty ? trimmedSSID : trimmedPrefix + "…"]))
                done?(true)
            }
        }
    }

    /// 跳到系统的 Wi-Fi 设置页（自签包可以用这个私有入口，App Store 上架才不允许）。
    @discardableResult
    func openSystemWiFi() -> Bool {
        for candidate in ["App-prefs:root=WIFI", "App-Prefs:root=WIFI", "prefs:root=WIFI"] {
            if let url = URL(string: candidate), UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                return true
            }
        }
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
            return true
        }
        return false
    }
}
