// 九号车把原生按键桥：接收仪表/中继上报的按键，并映射为 CarPlay 控制。
//
// 链路说明：
// - CarWithin 在九号 5/7/4.3 寸模式下只通过 UDP 5013 收发 RTCP 保活，原厂会话不会主动
//   把车把按键回传给手机。因此本模块提供两条入口：
//   1) UDP 监听（默认 5014），接收仪表端按键桥、adb 脚本或调试工具发来的按键；
//   2) 嗅探 5013 上的非心跳报文，把原始内容写进日志，便于实车确认原厂是否回传按键。
// - 按键报文接受纯文本（`up`、`up:down`、`key=up`）或 JSON（`{"key":"up"}`）。
import Foundation
import Darwin

/// 可映射的车把物理按键。rawValue 即报文里的键名（大小写、连字符不敏感）。
enum HandlebarKey: String, CaseIterable {
    case up, down, ok, back, mode, horn
    case leftTurn, rightTurn, highBeam
    case plus, minus, home, hook

    var title: String {
        switch self {
        case .up: CWL("上翻")
        case .down: CWL("下翻")
        case .ok: CWL("确认")
        case .back: CWL("返回")
        case .mode: CWL("模式键")
        case .horn: CWL("喇叭键")
        case .leftTurn: CWL("左转向")
        case .rightTurn: CWL("右转向")
        case .highBeam: CWL("远近光")
        case .plus: CWL("加号键")
        case .minus: CWL("减号键")
        case .home: CWL("主页键")
        case .hook: CWL("通话键")
        }
    }

    /// 归一化后匹配：忽略大小写、空格、`_` 和 `-`。
    static func parse(_ raw: String) -> HandlebarKey? {
        let normalized = raw.lowercased().filter { $0.isLetter || $0.isNumber }
        guard !normalized.isEmpty else { return nil }
        return allCases.first { $0.rawValue.lowercased() == normalized }
    }
}

/// 车把按键到 CarPlay 控制的映射。用户自定义存在 UserDefaults，未覆盖的键用默认值。
struct HandlebarKeyMapping {
    /// 翻页键走菜单焦点、确认键走选择、加减键也走焦点；转向灯、喇叭、远近光保持原车功能不动。
    /// 菜单要能操作，首先得让上/下/确认落到 knob/select 上，而不是映射成切歌。
    static let defaults: [HandlebarKey: CarPlayControl] = [
        .up: .knobPrevious,
        .down: .knobNext,
        .ok: .select,
        .back: .back,
        .mode: .siri,
        .plus: .knobNext,
        .minus: .knobPrevious,
        .home: .home,
        .hook: .hookSwitch
    ]

    private static let storageKey = "handlebarKeyMapping"
    private(set) var controls: [HandlebarKey: CarPlayControl]

    init() {
        var merged = Self.defaults
        if let stored = UserDefaults.standard.dictionary(forKey: Self.storageKey) {
            for (key, value) in stored {
                guard let name = value as? String, let parsed = HandlebarKey.parse(key),
                      let control = CarPlayControl(rawValue: name) else { continue }
                merged[parsed] = control
            }
        }
        controls = merged
    }

    func control(for key: HandlebarKey) -> CarPlayControl? { controls[key] }

    static func store(_ mapping: [HandlebarKey: CarPlayControl]) {
        let encoded = Dictionary(uniqueKeysWithValues: mapping.map { ($0.key.rawValue, $0.value.rawValue) })
        UserDefaults.standard.set(encoded, forKey: storageKey)
    }
}

/// UDP 按键接收器。所有 socket 操作与解析都在自己的串行队列上；回调由调用方决定线程。
final class HandlebarKeyReceiver: @unchecked Sendable {
    static let defaultPort: UInt16 = 5014

    private let queue = DispatchQueue(label: "CarWithin.handlebar", qos: .userInitiated)
    private var descriptor: Int32 = -1
    private var source: DispatchSourceRead?
    private var mapping = HandlebarKeyMapping()
    private var lastSniffSignature = ""
    private var lastSniffTime = -Double.infinity
    private(set) var listeningPort: UInt16 = 0

    /// 发送到 NativeReceiver.press()，由它决定线程。
    var onControl: ((CarPlayControl) -> Void)?
    var onLog: ((String) -> Void)?

    /// 取消读源时由本类同步关闭 fd：cancel handler 是异步执行的，若在新旧 socket 间复用同一个
    /// fd 号，延迟执行的关闭会把新 socket 一起关掉。
    deinit {
        source?.cancel()
        if descriptor >= 0 { Darwin.close(descriptor) }
    }

    func start(port: UInt16 = HandlebarKeyReceiver.defaultPort) {
        queue.async { [weak self] in self?.startOnQueue(port: port) }
    }

    func stop() {
        queue.async { [weak self] in self?.stopOnQueue() }
    }

    /// 记录九号控制通道上的未知报文。仅在内容变化或间隔超过 3 秒时输出，避免刷屏。
    func sniff(_ datagram: Data) {
        queue.async { [weak self] in
            guard let self else { return }
            let hex = datagram.prefix(24).map { String(format: "%02x", $0) }.joined(separator: " ")
            let signature = "\(datagram.count)|" + hex
            let now = ProcessInfo.processInfo.systemUptime
            guard signature != self.lastSniffSignature || now - self.lastSniffTime >= 3 else { return }
            self.lastSniffSignature = signature
            self.lastSniffTime = now
            self.onLog?(CWL("九号控制通道收到疑似按键报文：{1} 字节 · {2}",
                            [String(describing: datagram.count), hex]))
        }
    }

    private func startOnQueue(port: UInt16) {
        stopOnQueue()
        let fd = Darwin.socket(AF_INET, SOCK_DGRAM, 0)
        guard fd >= 0 else {
            onLog?(CWL("车把按键通道创建失败（errno {1}）", [String(describing: errno)]))
            return
        }
        var reuse: Int32 = 1
        _ = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &reuse, socklen_t(MemoryLayout<Int32>.size))
        var noSigPipe: Int32 = 1
        _ = setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &noSigPipe, socklen_t(MemoryLayout<Int32>.size))

        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = port.bigEndian
        address.sin_addr.s_addr = INADDR_ANY
        let bound = withUnsafePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bound == 0 else {
            let code = errno
            Darwin.close(fd)
            onLog?(CWL("车把按键通道绑定 UDP {1} 失败：{2} (errno {3})",
                       [String(describing: port), String(describing: String(cString: strerror(code))), String(describing: code)]))
            return
        }
        let flags = fcntl(fd, F_GETFL, 0)
        if flags >= 0 { _ = fcntl(fd, F_SETFL, flags | O_NONBLOCK) }

        descriptor = fd
        listeningPort = port
        let readSource = DispatchSource.makeReadSource(fileDescriptor: fd, queue: queue)
        readSource.setEventHandler { [weak self] in self?.drain() }
        source = readSource
        readSource.resume()
        onLog?(CWL("车把按键通道已监听 UDP {1}（九号模式下可用仪表桥或调试工具发送）", [String(describing: port)]))
    }

    private func stopOnQueue() {
        source?.cancel()
        source = nil
        if descriptor >= 0 {
            Darwin.close(descriptor)
            descriptor = -1
        }
        listeningPort = 0
        lastSniffSignature = ""
        lastSniffTime = -Double.infinity
    }

    private func drain() {
        guard descriptor >= 0 else { return }
        var buffer = [UInt8](repeating: 0, count: 512)
        while true {
            let count = Darwin.recv(descriptor, &buffer, buffer.count, MSG_DONTWAIT)
            guard count > 0 else { break }
            handle(Data(buffer.prefix(count)))
        }
    }

    private func handle(_ data: Data) {
        guard let text = String(data: data, encoding: .utf8) else {
            sniff(data)
            return
        }
        guard let key = Self.parseKey(text) else { sniff(data); return }
        guard let control = mapping.control(for: key) else {
            onLog?(CWL("车把按键「{1}」未配置动作", [key.title]))
            return
        }
        onLog?(CWL("车把按键「{1}」→ {2}", [key.title, control.title]))
        onControl?(control)
    }

    /// 解析 `up`、`up:down`、`key=up`、`{"key":"up"}` 等格式；`code` 字段也接受按键名。
    static func parseKey(_ raw: String) -> HandlebarKey? {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if text.hasPrefix("{"), let data = text.data(using: .utf8),
           let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] {
            if let key = object["key"] as? String { text = key }
            else if let key = object["code"] as? String { text = key }
            else { return nil }
        }
        for prefix in ["key=", "code="] where text.lowercased().hasPrefix(prefix) {
            text.removeFirst(prefix.count)
        }
        if let separator = text.firstIndex(where: { $0 == ":" || $0 == "&" || $0 == "," }) {
            text = String(text[..<separator])
        }
        return HandlebarKey.parse(text)
    }
}
