import UIKit

/// 屏幕上的"虚拟车把"。
///
/// 九号原厂 5 寸仪表直连时，车把按键被仪表固件自己消费，不会回传到手机；这个面板让
/// 用户先用手机屏幕把同一套 CarPlay 旋钮/选择事件发出去，确认菜单真的能被控制，
/// 再接物理输入源（UDP 5014 按键桥 / 中继盒子）。
final class HandlebarPadView: UIView {
    var onControl: ((CarPlayControl) -> Void)?

    private static let rows: [[(control: CarPlayControl, symbol: String)]] = [
        [(.knobPrevious, "chevron.up"), (.knobNext, "chevron.down"),
         (.select, "checkmark.circle"), (.back, "arrow.uturn.backward")],
        [(.home, "house.fill"), (.playPause, "playpause.fill"),
         (.previous, "backward.fill"), (.next, "forward.fill")]
    ]

    override init(frame: CGRect) {
        super.init(frame: frame)
        build()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        build()
    }

    private func build() {
        let symbolConfiguration = UIImage.SymbolConfiguration(pointSize: 14, weight: .semibold)
        let rowViews = Self.rows.map { items -> UIStackView in
            let buttons = items.map { item -> UIButton in
                var configuration = UIButton.Configuration.tinted()
                configuration.image = UIImage(systemName: item.symbol, withConfiguration: symbolConfiguration)
                configuration.title = item.control.title
                configuration.imagePadding = 5
                configuration.cornerStyle = .medium
                configuration.baseForegroundColor = .label
                configuration.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
                    var outgoing = incoming
                    outgoing.font = .preferredFont(forTextStyle: .footnote)
                    return outgoing
                }
                let button = UIButton(configuration: configuration)
                button.addAction(UIAction { [weak self] _ in self?.onControl?(item.control) }, for: .touchUpInside)
                return button
            }
            let row = UIStackView(arrangedSubviews: buttons)
            row.axis = .horizontal
            row.distribution = .fillEqually
            row.spacing = 8
            return row
        }
        let stack = UIStackView(arrangedSubviews: rowViews)
        stack.axis = .vertical
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor)
        ])
    }
}
