# 九号车把原生按键（CarWithin 侧）

## 先说清现状

CarWithin 1.0.5 的九号 5/7/4.3 寸输出只做了 **UDP 5012 视频 + UDP 5013 RTCP 保活**：
`NinebotOutput.tick()` 里从 5013 收到的包只有两种会被处理——心跳应答和七寸的 24 字节应答，
其余全部丢弃，没有按键解析。九号投屏的公开实现（`xmz28/ninebot_pro`）也把 5013 描述为
“RTCP 控制与保活”，没有公开的按键报文格式。

结论：**原厂会话不会主动把车把按键送到 iPhone**。要让车把按键控制 CarPlay，必须在仪表侧
把按键事件转发过来，或者在实车抓包确认原厂确实有回传。

本次改动不猜测协议，而是把两条入口都做好：

| 入口 | 用途 |
| --- | --- |
| UDP 5014 监听 | 仪表端按键桥、adb 脚本、调试工具把按键发给 CarWithin |
| 5013 未知报文嗅探 | 实车按键时把 5013 上的非心跳包写进日志，用于确认原厂有没有回传 |

## 默认映射

只接管仪表上的翻页/确认/模式键，**转向灯、喇叭、远近光不映射**，保持原车功能：

| 车把键 | CarPlay 动作 |
| --- | --- |
| `up` | 上一曲 |
| `down` | 下一曲 |
| `ok` | 播放/暂停 |
| `back` | 返回 |
| `mode` | Siri |
| `plus` / `minus` | 下一曲 / 上一曲 |
| `home` | 主页 |
| `hook` | 接听/挂断 |

需要改映射时，在 `UserDefaults` 写入 `handlebarKeyMapping`（字典：键名 → `CarPlayControl`
的 rawValue，例如 `{"up":"knobPrevious","mode":"playPause"}`）；未写入的键继续用默认值。
`CarPlayControl` 可选值：`home back select knobPrevious knobNext previous playPause next siri hookSwitch`。

## 报文格式（UDP 5014）

三种都接受，大小写和 `-`/`_` 不敏感：

```text
up
up:down
key=up
{"key":"up"}
```

## 实车验证步骤

1. 安装新 IPA，在「当前输出」选九号 5 寸（或 7 寸/4.3 寸），启动 CarPlay。
2. 看日志，出现下面这行说明 5014 已就绪：

   ```text
   车把按键通道已监听 UDP 5014（九号模式下可用仪表桥或调试工具发送）
   ```

3. 先在电脑上验证通路（iPhone 与电脑同一局域网）：

   ```sh
   python Tools/handlebar_key_sender.py <iPhone 的局域网 IP> up
   ```

   iPhone 日志应出现 `车把按键「上翻」→ 上一曲`。

4. **实车按车把键**，观察日志：
   - 出现 `九号控制通道收到疑似按键报文：N 字节 · xx xx ...`：说明原厂有回传，把这行发回来，
     可以直接做原生解析，不再依赖仪表桥。
   - 完全没有新日志：原厂不回传，只能走下面的仪表桥。

## 仪表端桥（需要仪表可 adb）

九号 5 寸仪表跑 Android。仪表能开 USB/无线调试、`adb devices` 能看到它时：

```sh
python Tools/handlebar_adb_bridge.py <iPhone 的局域网 IP> --dump
```

按一遍车把键，终端会打印 `KEY_xxx code=NNN`。把对应 keycode 补进脚本的 `KEYMAP`，
再去掉 `--dump` 就是可用桥：

```sh
python Tools/handlebar_adb_bridge.py <iPhone 的局域网 IP>
```

仪表没有 adb 权限时，这条路径走不通，需要换自研仪表端 App 或保留原厂功能键不动。

## 已知限制

- 本次改动**未在 M385cmax 实车验证**，只做了协议与代码层实现；5014 通路和默认映射可用调试工具先验证。
- 原厂投屏会话是否回传按键，必须以实车日志为准；不做无依据的协议猜测。
- 仪表端桥依赖 adb，且 `getevent` 需要能读到对应输入设备节点。
- 不接管转向灯、喇叭、远近光，避免影响行车功能。
