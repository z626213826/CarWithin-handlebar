// 陆行电量计（EM2APP / EM02）只读解析。
//
// 这块不是"嘉佰达保护板协议"：EM2APP 是计量模块，每拍用 4 条 Modbus FC03 读寄存器，
// 响应按数据长度分派。发给它嘉佰达的 `DD A5 …` 只会静默无回应，之前的"未返回有效实时帧"
// 就是这么来的。
//
//   读 4000 起 89 个 → 响应 len 178（设备信息，不解析）
//   读 4092 起 54 个 → 响应 len 108（实时：总压/电流/功率/单体/温度/SOC/容量）
//   读 4200 起 45 个 → 响应 len  90（中继保护板品牌/名称/MAC）
//   读 4152 起 48 个 → 响应 len  96（循环次数）
import Foundation

public struct LuXingMeterProtocol {
    private var buffer: [UInt8] = []
    private var pollIndex = 0
    private var reportedBrand: String?

    public init() {}

    /// 轮询节拍：实时帧占一半节拍，其余三条分摊，保证电压电流不会隔太久才更新一次。
    public mutating func nextQueries() -> [Data] {
        let frames: [Data]
        if pollIndex % 2 == 0 {
            frames = [Self.readFrame(unit: 1, start: 4092, count: 54)]
        } else {
            switch (pollIndex / 2) % 3 {
            case 0: frames = [Self.readFrame(unit: 1, start: 4200, count: 45)]
            case 1: frames = [Self.readFrame(unit: 1, start: 4152, count: 48)]
            default: frames = [Self.readFrame(unit: 1, start: 4000, count: 89)]
            }
        }
        pollIndex = (pollIndex + 1) % 6
        return frames
    }

    public mutating func append(_ data: Data) -> [ANTBMSReading] {
        buffer.append(contentsOf: [UInt8](data))
        if buffer.count > 4096 { buffer.removeFirst(buffer.count - 4096) }
        var out: [ANTBMSReading] = []
        while buffer.count >= 3 {
            guard buffer[0] == 0x01 else { buffer.removeFirst(); continue }
            let command = buffer[1]
            if command == 0x83 {
                // 非法数据地址等异常应答，固定 5 字节，直接丢掉。
                guard buffer.count >= 5 else { break }
                buffer.removeFirst(5)
                continue
            }
            guard command == 0x03 else { buffer.removeFirst(); continue }
            let length = Int(buffer[2])
            guard [178, 108, 90, 96].contains(length) else { buffer.removeFirst(); continue }
            let total = length + 5
            guard buffer.count >= total else { break }
            guard Self.crc16(Array(buffer[0..<(total - 2)])).crc == Self.u16(Array(buffer[0..<total]), total - 2) else {
                buffer.removeFirst()
                continue
            }
            let frame = Array(buffer[0..<total])
            buffer.removeFirst(total)
            switch length {
            case 108:
                if let reading = Self.decodeRealtime(frame), reading.voltage > 0 {
                    out.append(reading)
                }
            case 90:
                if let brand = Self.decodeRelayBrand(frame), brand != reportedBrand {
                    reportedBrand = brand
                }
            default:
                break
            }
        }
        return out
    }

    /// 中继保护板品牌：这辆车是"嘉佰达保护板 + 陆行计量模块"，品牌码 3 即嘉佰达。
    public var relayBoardBrand: String? { reportedBrand }

    static func decodeRealtime(_ frame: [UInt8]) -> ANTBMSReading? {
        guard frame.count >= 108 + 5 else { return nil }
        var reader = LittleEndianReader(frame, 3)
        let cellCount = min(reader.u8(), 30)
        _ = reader.u8()                       // batType
        let mosTempCount = reader.u8(); let mosTemp = reader.i8() - 40
        let balanceTempCount = reader.u8(); let balanceTemp = reader.i8() - 40
        _ = reader.u8()                       // 保留
        let batteryTempCount = reader.u8()
        let batteryTemps = (0..<8).map { _ in reader.i8() - 40 }
        _ = reader.u8(); _ = reader.u8()      // 最低/最高温度下标
        _ = reader.u8(); _ = reader.i8()      // 有效最高/最低温度（同为 +40 偏移）
        let powerRaw = reader.i16()
        let systemVoltageRaw = reader.u32()
        let systemCurrentRaw = reader.u32()
        guard cellCount >= 1 else { return nil }
        var cells: [Double?] = []
        for _ in 0..<cellCount {
            let raw = reader.u16()
            let value = Double(raw) / 1000
            cells.append(raw != 0xFFFF && (0.5...6).contains(value) ? value : nil)
        }
        reader.skip(60 - 2 * cellCount)
        _ = reader.u8(); _ = reader.u8()      // 最高/最低单体下标
        _ = reader.u16(); _ = reader.u16()    // 最高/最低单体电压
        _ = reader.u16(); _ = reader.u16()    // 最大充/放电流
        _ = reader.u8(); _ = reader.u8()      // 电流死区
        let ratedRaw = reader.u16()
        _ = reader.u16()                      // actualCapacity：官方不采用
        let soc = reader.u8()
        _ = reader.u8()                       // soh

        let voltage = systemVoltageRaw == 0xFFFF_FFFF ? 0 : Double(systemVoltageRaw) / 1000
        let current = systemCurrentRaw == 0x7FFF_FFFF ? 0 : Double(Int32(bitPattern: UInt32(truncatingIfNeeded: systemCurrentRaw))) / 100
        let ratedAh = ratedRaw == 0xFFFF ? 0 : Double(ratedRaw) / 10
        var temperatures: [Double?] = []
        if mosTempCount > 0 { temperatures.append(Double(mosTemp)) }
        if balanceTempCount > 0 { temperatures.append(Double(balanceTemp)) }
        for index in 0..<min(batteryTempCount, 8) { temperatures.append(Double(batteryTemps[index])) }
        let power = powerRaw == 32767 ? Int((voltage * current).rounded()) : Int(powerRaw)
        return ANTBMSReading(
            voltage: voltage,
            current: current,
            power: power,
            stateOfCharge: min(max(soc, 0), 100),
            stateOfHealth: nil,
            stateCode: current > 0.3 ? 2 : (current < -0.3 ? 1 : 0),
            capacityAh: ratedAh,
            remainingAh: ratedAh * Double(min(max(soc, 0), 100)) / 100,
            cells: cells,
            temperatures: temperatures,
            mosTemperature: temperatures.first ?? nil,
            protectionBits: 0,
            warningBits: 0)
    }

    static func decodeRelayBrand(_ frame: [UInt8]) -> String? {
        guard frame.count >= 90 + 5 else { return nil }
        var reader = LittleEndianReader(frame, 3)
        _ = reader.u8(); _ = reader.u8()      // 绑定/连接状态
        _ = reader.u16(); _ = reader.u16()    // 上下行包计数
        _ = reader.u16(); _ = reader.u16()    // 霍尔转速/车速
        _ = reader.u16(); _ = reader.u16()    // 温度
        _ = reader.u16(); _ = reader.u16()    // 电压校准
        _ = reader.u32()                      // 中继板自报电压：官方不采用，避免和计量值打架
        _ = reader.u8(); _ = reader.u8(); _ = reader.u16(); _ = reader.u8(); _ = reader.u8()
        for _ in 0..<11 { _ = reader.u16() }
        let vendor = reader.u8()
        _ = reader.bytes(33)                  // 中继板名称
        _ = reader.bytes(6)                   // MAC
        return Self.vendorName(vendor)
    }

    static func vendorName(_ id: Int) -> String? {
        switch id {
        case 1: return "彦阳保护板"
        case 2: return "蚂蚁保护板"
        case 3: return "嘉佰达保护板"
        case 4: return "极空保护板"
        case 5: return "超力源保护板"
        case 6: return "达理保护板"
        case 8: return "陆行电量计"
        case 9, 10: return "蓝宝电量计"
        case 12: return "明唐"
        default: return nil
        }
    }

    /// Modbus RTU 读保持寄存器（FC03）：[unit, 03, 起址高, 起址低, 数量高, 数量低, CRC低, CRC高]
    static func readFrame(unit: UInt8, start: Int, count: Int) -> Data {
        let body: [UInt8] = [unit, 0x03, UInt8((start >> 8) & 0xFF), UInt8(start & 0xFF),
                             UInt8((count >> 8) & 0xFF), UInt8(count & 0xFF)]
        let crc = crc16(body).crc
        return Data(body + [UInt8(crc & 0xFF), UInt8((crc >> 8) & 0xFF)])
    }

    static func crc16(_ bytes: [UInt8]) -> (crc: Int, ok: Bool) {
        var crc = 0xFFFF
        for byte in bytes {
            crc ^= Int(byte)
            for _ in 0..<8 { crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xA001 : crc >> 1 }
        }
        return (crc & 0xFFFF, true)
    }

    static func u16(_ bytes: [UInt8], _ offset: Int) -> Int {
        guard offset >= 0, offset + 1 < bytes.count else { return 0 }
        return Int(bytes[offset]) | Int(bytes[offset + 1]) << 8
    }
}

/// 小端读取器，与官方 EM02.js 的 `getUint16(..., true)` 保持一致。
struct LittleEndianReader {
    private let bytes: [UInt8]
    private var position: Int

    init(_ bytes: [UInt8], _ start: Int) {
        self.bytes = bytes
        self.position = start
    }

    mutating func u8() -> Int {
        guard position < bytes.count else { position += 1; return 0 }
        defer { position += 1 }
        return Int(bytes[position])
    }

    mutating func i8() -> Int {
        guard position < bytes.count else { position += 1; return 0 }
        defer { position += 1 }
        return Int(Int8(bitPattern: bytes[position]))
    }

    mutating func u16() -> Int {
        let value = u16At(position) | (u16At(position + 1) << 8)
        position += 2
        return value
    }

    mutating func i16() -> Int {
        let value = u16()
        return value >= 0x8000 ? value - 0x10000 : value
    }

    mutating func u32() -> UInt32 {
        let low = UInt32(u16()) & 0xFFFF
        let high = UInt32(u16()) & 0xFFFF
        return (high << 16) | low
    }

    mutating func skip(_ count: Int) { position += count }

    mutating func bytes(_ count: Int) -> [UInt8] {
        guard position >= 0, position < bytes.count else { position += count; return [] }
        let slice = Array(bytes[position..<min(position + count, bytes.count)])
        position += count
        return slice
    }

    private func u16At(_ offset: Int) -> Int {
        guard offset >= 0, offset < bytes.count else { return 0 }
        return Int(bytes[offset])
    }
}
