// 嘉佰达（JBD / Jiabaida）只读实时解码。
//
// 帧格式：写 `DD A5 <cmd> 00 FF <-cmd> 77`，读回 `DD <cmd> <status> <len> <data> <crc16> 77`。
// 只发 0x03（基本信息）与 0x04（单体电压），不接触 0x5A / 0x16 等写入或工厂命令。
import Foundation

public struct JBDBMSProtocol {
    /// 轮询用的两条只读命令。
    public static func query(_ command: UInt8) -> Data {
        Data([0xDD, 0xA5, command, 0x00, 0xFF, UInt8(truncatingIfNeeded: 0 &- Int(command)), 0x77])
    }

    private var buffer: [UInt8] = []
    private var basic: Basic?
    private var cells: [Double?] = []
    private var lastCommandLatency: UInt8 = 0x03

    struct Basic {
        var voltage: Double
        var current: Double
        var remaining: Double
        var nominal: Double
        var cycles: Int
        var soc: Int?
        var cells: Int
        var temperatures: [Double?]
        var protection: UInt64
    }

    public init() {}

    /// 下一次该发的命令：先基本信息，再单体电压，交替进行。
    public mutating func nextQuery() -> Data { Self.query(lastCommandLatency) }

    public mutating func append(_ data: Data) -> [ANTBMSReading] {
        buffer.append(contentsOf: [UInt8](data))
        if buffer.count > 2048 { buffer.removeFirst(buffer.count - 2048) }
        var out: [ANTBMSReading] = []
        while true {
            guard let start = buffer.firstIndex(of: 0xDD) else { buffer.removeAll(); break }
            if start > 0 { buffer.removeFirst(start) }
            guard buffer.count >= 4 else { break }
            if buffer[1] == 0xA5 { buffer.removeFirst(); continue }  // 被回显的请求
            let command = buffer[1]
            let length = Int(buffer[3])
            let total = 4 + length + 3
            guard buffer.count >= total else { break }
            guard buffer[total - 1] == 0x77,
                  Self.crc16(buffer, 2, 4 + length) == Self.u16(buffer, total - 3) else {
                buffer.removeFirst(); continue
            }
            let status = buffer[2]
            let payload = Array(buffer[4..<(4 + length)])
            buffer.removeFirst(total)
            guard command == 0x03 || command == 0x04, status == 0 else { continue }
            lastCommandLatency = command == 0x03 ? 0x04 : 0x03
            if command == 0x03, let decoded = Self.decodeBasic(payload) {
                basic = decoded
            } else if command == 0x04, !payload.isEmpty, payload.count % 2 == 0 {
                cells = stride(from: 0, to: payload.count, by: 2).map { index -> Double? in
                    let raw = Self.u16(payload, index)
                    guard raw != 0, raw != 0xFFFF else { return nil }
                    let value = Double(raw) / 1000
                    return (0.5...6).contains(value) ? value : nil
                }
            }
            if let reading = combined() { out.append(reading) }
        }
        return out
    }

    private func combined() -> ANTBMSReading? {
        guard let basic else { return nil }
        guard basic.voltage > 0, basic.voltage <= 650 else { return nil }
        return ANTBMSReading(
            voltage: basic.voltage,
            current: basic.current,
            power: Int((basic.voltage * basic.current).rounded()),
            stateOfCharge: basic.soc ?? 0,
            stateOfHealth: nil,
            stateCode: 0,
            capacityAh: basic.nominal,
            remainingAh: basic.remaining,
            cells: cells,
            temperatures: basic.temperatures,
            mosTemperature: basic.temperatures.first ?? nil,
            protectionBits: basic.protection,
            warningBits: 0)
    }

    static func decodeBasic(_ data: [UInt8]) -> Basic? {
        guard data.count >= 23 else { return nil }
        let scale = (data[20] & 0x80) != 0 ? 0.1 : 0.01
        let voltage = Double(u16(data, 0)) / 100
        let current = -Double(signed16(data, 2)) * scale
        let remaining = Double(u16(data, 4)) * scale
        let nominal = Double(u16(data, 6)) * scale
        let cycles = u16(data, 8)
        let soc = data[19] <= 100 ? Int(data[19]) : nil
        let cellCount = Int(data[21])
        let ntcCount = Int(data[22])
        guard (1...32).contains(cellCount), ntcCount <= 16, data.count >= 23 + ntcCount * 2 else { return nil }
        let temperatures: [Double?] = (0..<ntcCount).map { index in
            let raw = u16(data, 23 + index * 2)
            guard raw != 0, raw != 0xFFFF else { return nil }
            return (Double(raw) - 2731) / 10
        }
        return Basic(voltage: voltage, current: current, remaining: remaining, nominal: nominal,
                     cycles: cycles, soc: soc, cells: cellCount, temperatures: temperatures,
                     protection: UInt64(u16(data, 16)))
    }

    static func u16(_ bytes: [UInt8], _ offset: Int) -> Int {
        guard offset + 1 < bytes.count else { return 0 }
        return Int(bytes[offset]) << 8 | Int(bytes[offset + 1])
    }

    static func signed16(_ bytes: [UInt8], _ offset: Int) -> Int {
        Int(Int16(bitPattern: UInt16(truncatingIfNeeded: u16(bytes, offset))))
    }

    /// 嘉佰达用"和的补码"作 16 位校验。
    static func crc16(_ bytes: [UInt8], _ from: Int, _ toExclusive: Int) -> Int {
        var total = 0
        for index in from..<min(toExclusive, bytes.count) { total = (total + Int(bytes[index])) & 0xFFFF }
        return (0 &- total) & 0xFFFF
    }
}
