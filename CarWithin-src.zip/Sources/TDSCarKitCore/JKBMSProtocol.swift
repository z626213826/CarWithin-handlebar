// 极空（JK / Jikong）只读实时解码，覆盖 JK02 24S / JK02 32S。
//
// 写 20 字节命令帧 `AA 55 90 EB <cmd> 00…<sum>`，cmd=0x97 取设备信息、0x96 取实时数据；
// 读回 `55 AA EB 90 <type>` 起头的 300 字节帧（type=2 实时、type=3 信息），末字节为前面所有字节之和。
// JK04 浮点板不在此实现内（其报文结构与 JK02 完全不同），读到只会报"暂不支持"。
import Foundation

public struct JKBMSProtocol {
    public static func query(_ command: UInt8) -> Data {
        var frame = [UInt8](repeating: 0, count: 20)
        frame[0] = 0xAA
        frame[1] = 0x55
        frame[2] = 0x90
        frame[3] = 0xEB
        frame[4] = command
        frame[19] = UInt8(frame[0..<19].reduce(0) { ($0 + Int($1)) & 0xFF })
        return Data(frame)
    }

    private var buffer: [UInt8] = []
    private var version: Int?
    private var model: String?
    private var lastError: String?

    public init() {}

    public var ready: Bool { version != nil }

    public mutating func nextQuery() -> Data { Self.query(version == nil ? 0x97 : 0x96) }

    public mutating func append(_ data: Data) -> [ANTBMSReading] {
        buffer.append(contentsOf: [UInt8](data))
        if buffer.count > 1200 { buffer.removeFirst(buffer.count - 1200) }
        var out: [ANTBMSReading] = []
        while buffer.count >= 5 {
            let head = Array(buffer.prefix(4))
            if head == [0xAA, 0x55, 0x90, 0xEB] {
                // 模块把命令帧回显回来，直接丢掉。
                let trim = min(20, buffer.count)
                buffer.removeFirst(trim)
                continue
            }
            guard head == [0x55, 0xAA, 0xEB, 0x90] else {
                buffer.removeFirst()
                continue
            }
            let type = buffer[4]
            let length = type == 2 ? 300 : 20
            guard buffer.count >= length else { break }
            guard UInt8(buffer[0..<(length - 1)].reduce(0) { ($0 + Int($1)) & 0xFF }) == buffer[length - 1] else {
                lastError = "极空帧校验失败"
                buffer.removeFirst()
                continue
            }
            let frame = Array(buffer.prefix(length))
            buffer.removeFirst(length)
            if type == 3 {
                if let info = Self.decodeInfo(frame) {
                    version = info.major
                    model = info.model
                    lastError = nil
                } else {
                    lastError = "极空设备信息不兼容，请核对蓝牙设备"
                }
            } else if type == 2, let major = version, let reading = Self.decodeLive(frame, major: major) {
                out.append(reading)
            }
        }
        return out
    }

    struct Info { var model: String; var major: Int }

    static func decodeInfo(_ frame: [UInt8]) -> Info? {
        let model = text(frame, 6, 16)
        let software = text(frame, 30, 8)
        var digits = ""
        for char in software.drop(while: { $0 == "V" || $0 == "v" }) {
            if char.isNumber { digits.append(char) } else { break }
        }
        guard model.uppercased().hasPrefix("JK"), let major = Int(digits), (1...99).contains(major) else { return nil }
        return Info(model: model, major: major)
    }

    static func decodeLive(_ frame: [UInt8], major: Int) -> ANTBMSReading? {
        guard frame.count >= 300 else { return nil }
        let offset = major < 11 ? -32 : 0
        let slots = major < 11 ? 24 : 32
        let cellMask = u32(frame, 70 + offset / 2)
        var count = 0
        for index in 0..<slots where cellMask & (UInt32(1) << UInt32(index)) != 0 { count = index + 1 }
        guard count >= 1 else { return nil }
        let voltage = Double(u32(frame, 150 + offset)) / 1000
        let current = -Double(i32(frame, 158 + offset)) / 1000
        guard voltage > 0, voltage <= 200, current.isFinite else { return nil }
        let remaining = Double(u32(frame, 174 + offset)) / 1000
        let nominal = Double(u32(frame, 178 + offset)) / 1000
        let soc = Int(frame[173 + offset])
        let soh = Int(frame[190 + offset])
        let cycles = u32(frame, 182 + offset)
        let balancing = frame[172 + offset] != 0
        let charging = frame[198 + offset] != 0
        let discharging = frame[199 + offset] != 0
        let rawFaults = u32(frame, 166 + offset)
        let faults = offset != 0 ? rawFaults >> 16 : rawFaults
        let mask = Int(frame[214 + offset])
        var positions: [(name: String, offset: Int)] = major < 11
            ? [("T1", 130), ("T2", 132), ("MOS", 134)]
            : [("MOS", 144), ("T1", 162), ("T2", 164), ("MOS2", 254)]
        if major >= 14 { positions += [("T3", 256), ("T4", 258)] }
        let temperatures: [Double?] = positions.enumerated().map { index, item in
            guard mask & (1 << index) != 0 else { return nil }
            let raw = signed16(frame, item.offset)
            guard raw != -2000 else { return nil }
            return Double(raw) / 10
        }
        let cells: [Double?] = (0..<count).map { index in
            guard cellMask & (UInt32(1) << UInt32(index)) != 0 else { return nil }
            let raw = u16(frame, 6 + index * 2)
            guard (1...5000).contains(raw) else { return nil }
            return Double(raw) / 1000
        }
        var protection: UInt64 = 0
        for bit in 0..<32 where faults & (UInt32(1) << UInt32(bit)) != 0 && bit != 4 && bit != 19 {
            protection |= UInt64(1) << UInt64(bit)
        }
        let mosTemperature = temperatures.first ?? nil
        return ANTBMSReading(
            voltage: voltage,
            current: current,
            power: Int((voltage * current).rounded()),
            stateOfCharge: soc <= 100 ? soc : 0,
            stateOfHealth: soh <= 100 ? soh : nil,
            stateCode: charging ? 1 : (discharging ? 2 : 0),
            capacityAh: nominal,
            remainingAh: remaining,
            cells: cells,
            temperatures: temperatures,
            mosTemperature: mosTemperature,
            protectionBits: protection,
            warningBits: 0)
    }

    static func u16(_ bytes: [UInt8], _ offset: Int) -> Int {
        guard offset + 1 < bytes.count, offset >= 0 else { return 0 }
        return Int(bytes[offset]) | Int(bytes[offset + 1]) << 8
    }

    static func signed16(_ bytes: [UInt8], _ offset: Int) -> Int {
        Int(Int16(bitPattern: UInt16(truncatingIfNeeded: u16(bytes, offset))))
    }

    static func i32(_ bytes: [UInt8], _ offset: Int) -> Int32 {
        Int32(bitPattern: UInt32(truncatingIfNeeded: u16(bytes, offset) | (u16(bytes, offset + 2) << 16)))
    }

    static func u32(_ bytes: [UInt8], _ offset: Int) -> UInt32 { UInt32(bitPattern: i32(bytes, offset)) }

    static func text(_ bytes: [UInt8], _ offset: Int, _ length: Int) -> String {
        guard offset >= 0, offset + length <= bytes.count else { return "" }
        let slice = bytes[offset..<(offset + length)].prefix { $0 != 0 }
        return String(decoding: slice.filter { (32...126).contains($0) }, as: UTF8.self).trimmingCharacters(in: .whitespaces)
    }
}
